# MIGRATION_LOG
## Tahap 1 (parsial)
- Dibuat: NOTICE.md, PROJECT_STATUS.md, ARCHITECTURE.md, MIGRATION_LOG.md, TODO.md, KNOWN_ISSUES.md, third_party/*
- Diubah: androidApp/build.gradle.kts (applicationId, versionCode, archivesName), gradle.properties (versionName), settings.gradle.kts (rootProject.name), androidApp strings app_name, AndroidManifest (hapus 2 filter autoVerify), commonUi AppLinks.website
- Dihapus: secrets.enc, encrypt.sh, decrypt.sh
## Tahap 1 (lanjutan)
- AppLinks: source/issue/terms/changelog -> github.com/ganjarboy033/Cutefetch; telegram -> bagja.dev. feedbackEmail masih feedback@ymusic.io (menunggu email Cute Fetcher).
- Ditambah: .github/workflows/build.yml (ffmpeg 4 ABI + android + rilis draf pada tag v*).
- Dipindah: release.yml YMusic -> docs_referensi/YMusic_release.yml.txt (agar tidak terpicu tag release-*).
## Tahap 2 (UI Downloader + kontrak) — ditulis, BELUM dikompilasi
- Dibuat: modul `:pengambil_media` (ModelMedia.kt, ValidasiUrl.kt, PengelolaScraper.kt, MesinUnduh.kt, tes commonTest).
- Dibuat: commonUi/PengunduhScreen.kt (hero gradien, kotak masukan dengan bingkai animasi saat memuat, lencana platform, kartu hasil + chip format, antrean dengan progres/jeda/lanjut/batal).
- Diubah: settings.gradle.kts (include modul), commonUi/build.gradle.kts (api :pengambil_media), App.kt (AppSection.Pengunduh id 11 + cabang when + import), strings.xml (values, values-id, values-in; 29 kunci pengunduh_*), email umpan balik -> ganjarboy033@gmail.com.
- Nama fungsi pakai camelCase Indonesia (validasiUrl, deteksiPlatform), bukan snake_case, agar lolos ktlint/Spotless.
## Tahap 3 (mesin ekstraksi) — ditulis, BELUM dikompilasi/diuji
- Keputusan runtime: WebView + OkHttp (bukan QuickJS), karena 10/16 scraper memakai DOMParser.
- Dibuat: pengambil_media/PemetaHasilNimiyo.kt (+tes), FormatMedia.perluResolusi/dataMentah.
- Dibuat: androidApp/.../mesin/MesinWebViewNimiyo.kt; assets/scraper/** (disalin dari Musikku = scraper Nimiyo yang hilang dari ZIP Nimiyo; host.js: MusikkuNative->CuteNative, MusikkuHost->CuteHost).
- Diubah: AppGraph (pengelolaScraper, mesinUnduh), App.kt (layar memakai graph), YMusicApplication (properti lazy + argumen), androidApp/build.gradle.kts (:pengambil_media, androidx.webkit 1.12.1).
- Keamanan: WebView memblokir semua host selain aset lokal; jembatan HTTP hanya http/https; badan respons dibatasi 8 MB.
