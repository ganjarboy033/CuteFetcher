// Dipindahkan dari app.js Nimiyo (downloadSingleFile, tahap 1A-1D) tanpa mengubah logikanya.
// Fungsi ini mengubah URL semu seperti "ytmp3gg_resolve:..." menjadi URL unduhan sungguhan.
import "./scrapers/index.js"; // memastikan window.nimiyoEngine terpasang

export async function resolveDownloadUrl(dlItem) {
  let downloadUrl = dlItem.url;
  // Variabel konteks yang dulu berasal dari UI Nimiyo; di sini diberi nilai sederhana.
  const mediaResult = {};
  const mediaCategory = "audio";
  const currentPlatform = null;
  const targetExtension = "mp3";
  const isGenericMediaTitle = (s) => !s || /^(untitled|unknown|media|download)\b/i.test(s);
  const buildTargetFilename = (item) => item.title || item.type || "audio";
  const itemTitle = dlItem.title || dlItem.type || "";
  let sanitizedFilename = itemTitle;

  // 1A. Spotify SpotiDown Lazy Resolving
  if (downloadUrl.startsWith("spotidown_resolve:")) {
    console.log("[SPOTIFY RESOLVE] Resolving SpotiDown token for track:", itemTitle);
    const parts = downloadUrl.replace("spotidown_resolve:", "").split("|||");
    const payload = parts[0];
    let cookie = decodeURIComponent(parts[1] || "");

    try {
      if (!cookie) {
        try {
          const homeRes = window.nimiyoEngine?.scraperFetch
            ? await window.nimiyoEngine.scraperFetch({ url: "https://spotidown.app/", rawResponse: true }, "SpotiDown Cookie")
            : await fetch("https://spotidown.app/");
          const hHeaders = homeRes?.headers || {};
          const sc = hHeaders["set-cookie"] || hHeaders["Set-Cookie"] || "";
          if (sc) cookie = typeof sc === "string" ? sc.split(";")[0] : sc[0].split(";")[0];
        } catch (_) {}
      }

      let data = null;
      if (window.nimiyoEngine?.scraperFetch) {
        data = await window.nimiyoEngine.scraperFetch({
          url: "https://spotidown.app/action/track",
          method: "POST",
          data: payload,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest",
            Referer: "https://spotidown.app/",
            Origin: "https://spotidown.app",
            Cookie: cookie
          },
          rawResponse: true
        }, "SpotiDown Track Resolve");
      } else {
        const res = await fetch("https://spotidown.app/action/track", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest",
            Referer: "https://spotidown.app/",
            Origin: "https://spotidown.app",
            Cookie: cookie
          },
          body: payload
        });
        data = await res.json();
      }

      let parsedData = data;
      if (typeof data === "string") {
        try { parsedData = JSON.parse(data); } catch (_) { }
      } else if (data?.data) {
        if (typeof data.data === "string" && (data.data.startsWith("{") || data.data.startsWith("["))) {
          try { parsedData = JSON.parse(data.data); } catch (_) { parsedData = data.data; }
        } else {
          parsedData = data.data;
        }
      }

      const htmlContent = parsedData?.data || (typeof parsedData === "string" ? parsedData : "");
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlContent, "text/html");

      const resolvedTrackTitle = doc.querySelector("h3")?.textContent?.trim() || "";
      const resolvedArtist = doc.querySelector("p")?.textContent?.trim() || "";
      if (resolvedTrackTitle) {
        const resolvedFull = resolvedArtist ? `${resolvedArtist} - ${resolvedTrackTitle}` : resolvedTrackTitle;
        if (resolvedFull && !isGenericMediaTitle(resolvedFull)) {
          dlItem.title = resolvedFull;
          sanitizedFilename = buildTargetFilename(dlItem, mediaResult, mediaCategory, currentPlatform, targetExtension);
        }
      }

      const allAnchors = Array.from(doc.querySelectorAll("a"));
      let mp3Url = "";
      let fallbackUrl = "";

      for (const a of allAnchors) {
        const href = a.getAttribute("href") || "";
        const text = (a.textContent || "").toLowerCase();

        if (!href.startsWith("http") || href.includes("premium.html") || href === "https://spotidown.app/" || href === "https://spotidown.app") {
          continue;
        }

        if (text.includes("cover") || href.includes("cover")) {
          continue;
        }

        if (text.includes("mp3") || text.includes("download mp3") || text.includes("song") || href.includes("rapid.spotidown.app") || href.includes("/v2?token=")) {
          mp3Url = href;
          break;
        }

        if (!fallbackUrl) {
          fallbackUrl = href;
        }
      }

      const resolvedUrl = mp3Url || fallbackUrl;
      if (!resolvedUrl) {
        throw new Error("[NETWORK DOWNLOAD FAILED] Could not find download link in SpotiDown response.");
      }
      downloadUrl = resolvedUrl;
    } catch (e) {
      console.error("[SPOTIFY RESOLVE] Error resolving SpotiDown token:", e);
      throw new Error(`[NETWORK DOWNLOAD FAILED] Spotify resolve failed: ${e.message}`);
    }
  }

  // 1B. Spotify SoundLoaders Lazy Resolving
  if (downloadUrl.startsWith("soundloaders_resolve:")) {
    console.log("[SPOTIFY RESOLVE] Resolving SoundLoaders token for track:", itemTitle);
    const parts = downloadUrl.replace("soundloaders_resolve:", "").split("|||");
    const dataVal = parts[0];
    const tokenVal = parts[1];
    const baseVal = parts[2] ? decodeURIComponent(parts[2]) : "https://open.spotify.com";
    const cookiesVal = parts[3] ? decodeURIComponent(parts[3]) : "";

    try {
      let resData = null;
      const formBody = new URLSearchParams({
        data: dataVal,
        token: tokenVal,
        base: baseVal,
        "g-recaptcha-response": "dummy_token"
      }).toString();

      const fetchHelper = window.nimiyoEngine?.scraperFetch || window.nimiyoEngine?.scraperFetch;
      const headers = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest",
        Referer: "https://spotimate.app/en1",
        Origin: "https://spotimate.app",
        Cookie: cookiesVal
      };

      if (fetchHelper) {
        resData = await fetchHelper({
          url: "https://spotimate.app/action/track",
          method: "POST",
          headers,
          data: formBody,
          rawResponse: true
        }, "Spotimate Track Resolve");
      } else {
        const res = await fetch("https://spotimate.app/action/track", {
          method: "POST",
          headers,
          body: formBody
        });
        resData = await res.json();
      }

      let parsedData = resData;
      if (typeof resData === "string") {
        try { parsedData = JSON.parse(resData); } catch (_) { }
      } else if (resData?.data) {
        parsedData = resData.data;
        if (typeof parsedData === "string") {
          try { parsedData = JSON.parse(parsedData); } catch (_) { }
        }
      }

      const htmlContent = parsedData?.data || parsedData?.html || (typeof parsedData === "string" ? parsedData : "");
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlContent, "text/html");

      const resolvedTrackTitle = doc.querySelector("h2, h3, .title")?.textContent?.trim() || "";
      if (resolvedTrackTitle && !isGenericMediaTitle(resolvedTrackTitle)) {
        dlItem.title = resolvedTrackTitle;
        sanitizedFilename = buildTargetFilename(dlItem, mediaResult, mediaCategory, currentPlatform, targetExtension);
      }

      let resolvedUrl = "";
      const allAnchors = Array.from(doc.querySelectorAll("a"));
      for (const a of allAnchors) {
        const link = a.getAttribute("href") || "";
        const text = (a.textContent || "").toLowerCase();
        if (!link.startsWith("http") || link.includes("premium.html") || link.includes("/en1") || link.includes("/en7") || link.includes("spotimate.app/en") || link.includes("soundloaders.app/en")) {
          continue;
        }
        const isCoverLink = text.includes("cover") || link.includes("cover") || link.includes("i.scdn.co") || /\.(jpg|jpeg|png|webp)($|\?)/i.test(link);
        if (isCoverLink) {
          continue;
        }
        if (link.includes("dl.spotimate.app") || link.includes("dl.soundloaders.app") || link.includes("token=") || text.includes("mp3") || text.includes("song") || text.includes("download")) {
          resolvedUrl = link;
          break;
        }
        if (!resolvedUrl) {
          resolvedUrl = link;
        }
      }

      if (!resolvedUrl) {
        throw new Error("[NETWORK DOWNLOAD FAILED] Could not find download link in Spotimate response.");
      }
      downloadUrl = resolvedUrl;
    } catch (e) {
      console.error("[SPOTIFY RESOLVE] Error resolving SoundLoaders token:", e);
      throw new Error(`[NETWORK DOWNLOAD FAILED] SoundLoaders resolve failed: ${e.message}`);
    }
  }

  // 1B3. Spotify Spotisaver Lazy Resolving
  if (downloadUrl.startsWith("spotisaver_resolve:")) {
    console.log("[SPOTIFY RESOLVE] Resolving Spotisaver token for track:", itemTitle);
    const parts = downloadUrl.replace("spotisaver_resolve:", "").split("|||");
    const trackId = parts[0];
    const trackName = decodeURIComponent(parts[1] || "");
    const duration = parts[2] || "0";
    const cookiesVal = parts[3] ? decodeURIComponent(parts[3]) : "";

    try {
      const BASE = "https://spotisaver.net";
      const fetchHelper = window.nimiyoEngine?.scraperFetch || window.nimiyoEngine?.scraperFetch;
      const ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
      const dlCtx = { lang: "en", id: trackId, name: trackName, duration_ms: String(duration) };
      const b64 = btoa(JSON.stringify(dlCtx)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
      const sigParams = new URLSearchParams({
        _t: "455b447694e16f8ceacaa717f18ba309675dafb36687859a5d69d39798046221",
        _a: "download_track",
        _c: b64,
      });

      const rSig = fetchHelper
        ? await fetchHelper({
            url: `${BASE}/api/get_signature.php?${sigParams.toString()}`,
            headers: { "User-Agent": ua, Accept: "application/json", Referer: BASE + "/en1", Cookie: cookiesVal },
          }, "Spotisaver Sig Resolve")
        : await (await fetch(`${BASE}/api/get_signature.php?${sigParams.toString()}`, { headers: { "User-Agent": ua, Accept: "application/json" } })).json();

      if (rSig?.token) {
        downloadUrl = `${BASE}/api/download_track.php?id=${trackId}`;
      } else {
        throw new Error("Could not obtain Spotisaver download token");
      }
    } catch (e) {
      console.error("[SPOTIFY RESOLVE] Error resolving Spotisaver token:", e);
      throw new Error(`[NETWORK DOWNLOAD FAILED] Spotisaver resolve failed: ${e.message}`);
    }
  }

  // 1C. YouTube Playlist Lazy Resolving (ytmp3gg_resolve:videoId|||format|||quality)
  if (downloadUrl.startsWith("ytmp3gg_resolve:")) {
    console.log("[YOUTUBE RESOLVE] Resolving ytmp3gg token:", sanitizedFilename);
    const parts = downloadUrl.replace("ytmp3gg_resolve:", "").split("|||");
    const videoId = parts[0];
    const format = parts[1] || "mp3";
    const quality = parts[2] || "128";
    const targetUrl = `https://www.youtube.com/watch?v=${videoId}`;

    try {
      const headers = {
        Origin: "https://media.ytmp3.gg",
        Referer: "https://media.ytmp3.gg/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        Accept: "application/json, text/plain, */*",
        "Content-Type": "application/json"
      };

      let convRes = null;
      if (window.nimiyoEngine?.scraperFetch) {
        convRes = await window.nimiyoEngine.scraperFetch({
          url: "https://hub.convert1s.com/api/download",
          method: "POST",
          headers,
          data: JSON.stringify({
            url: targetUrl,
            os: "macos",
            output: {
              type: format === "mp4" ? "video" : "audio",
              format,
              quality,
            },
            audio: { bitrate: "128k" },
          }),
          rawResponse: true,
        }, "ytmp3.gg Playlist Resolve");
      } else {
        const res = await fetch("https://hub.convert1s.com/api/download", {
          method: "POST",
          headers,
          body: JSON.stringify({
            url: targetUrl,
            os: "macos",
            output: {
              type: format === "mp4" ? "video" : "audio",
              format,
              quality,
            },
            audio: { bitrate: "128k" },
          }),
        });
        convRes = { data: await res.json() };
      }

      let conv = convRes?.data;
      if (typeof conv === "string") {
        try { conv = JSON.parse(conv); } catch (_) { }
      }

      if (!conv || conv.error || !conv.statusUrl) {
        throw new Error(conv?.message || conv?.error || "Conversion failed on ytmp3.gg");
      }

      let resolvedDlUrl = null;
      let attempts = 0;
      while (!resolvedDlUrl && attempts < 30) {
        await new Promise((r) => setTimeout(r, 1500));
        let pollData = null;
        if (window.nimiyoEngine?.scraperFetch) {
          pollData = await window.nimiyoEngine.scraperFetch({
            url: conv.statusUrl,
            headers,
          }, "ytmp3.gg Status");
        } else {
          const pRes = await fetch(conv.statusUrl, { headers });
          pollData = await pRes.json();
        }
        attempts++;
        if (pollData && pollData.status === "completed" && pollData.downloadUrl) {
          resolvedDlUrl = pollData.downloadUrl;
          break;
        }
        if (pollData && (pollData.status === "error" || pollData.status === "failed")) {
          break;
        }
      }

      if (!resolvedDlUrl) {
        console.warn("[YOUTUBE RESOLVE] Primary convert failed, trying ymcdn fallback...");
        try {
          const fetchHelper = window.nimiyoEngine?.scraperFetch || window.nimiyoEngine?.scraperFetch;
          const ymHeaders = {
            Origin: "https://ytmp3.mobi",
            Referer: "https://ytmp3.mobi/en8/",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
            Accept: "*/*"
          };
          const initData = fetchHelper
            ? await fetchHelper({ url: `https://a.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, headers: ymHeaders }, "YTMobi Init")
            : await (await fetch(`https://a.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, { headers: ymHeaders })).json();

          if (initData?.convertURL) {
            let convData = fetchHelper
              ? await fetchHelper({ url: `${initData.convertURL}&v=${videoId}&f=${format}&_=${Math.random()}`, headers: ymHeaders }, "YTMobi Convert")
              : await (await fetch(`${initData.convertURL}&v=${videoId}&f=${format}&_=${Math.random()}`, { headers: ymHeaders })).json();

            let redirCount = 0;
            while (convData && convData.redirect > 0 && convData.redirectURL && redirCount < 5) {
              redirCount++;
              convData = fetchHelper
                ? await fetchHelper({ url: `${convData.redirectURL}&v=${videoId}&f=${format}&_=${Math.random()}`, headers: ymHeaders }, "YTMobi Redirect")
                : await (await fetch(`${convData.redirectURL}&v=${videoId}&f=${format}&_=${Math.random()}`, { headers: ymHeaders })).json();
            }

            if (convData && !convData.error) {
              let progress = convData.progress || 0;
              let ymAttempts = 0;
              while (progress < 3 && ymAttempts < 12 && convData.progressURL) {
                await new Promise((r) => setTimeout(r, 1200));
                const progData = fetchHelper
                  ? await fetchHelper({ url: `${convData.progressURL}&_=${Math.random()}`, headers: ymHeaders }, "YTMobi Progress")
                  : await (await fetch(`${convData.progressURL}&_=${Math.random()}`, { headers: ymHeaders })).json();
                if (!progData || progData.error) break;
                progress = progData.progress ?? 0;
                if (progData.downloadURL) resolvedDlUrl = progData.downloadURL;
                if (progress === 4) break;
                ymAttempts++;
              }
              if (convData.downloadURL && !resolvedDlUrl) resolvedDlUrl = convData.downloadURL;
            }
          }
        } catch (ymErr) {
          console.warn("[YOUTUBE RESOLVE] ymcdn fallback failed:", ymErr);
        }
      }

      if (!resolvedDlUrl) {
        throw new Error("[NETWORK DOWNLOAD FAILED] Conversion timed out or failed on YouTube servers.");
      }
      if (resolvedDlUrl.startsWith("//")) resolvedDlUrl = "https:" + resolvedDlUrl;
      downloadUrl = resolvedDlUrl;
    } catch (e) {
      console.error("[YOUTUBE RESOLVE] Error resolving ytmp3gg token:", e);
      throw new Error(`[NETWORK DOWNLOAD FAILED] YouTube resolve failed: ${e.message}`);
    }
  }

  // 1D. Apple Music Lazy Resolving (applemusic_resolve:payloadStr)
  if (downloadUrl.startsWith("applemusic_resolve:")) {
    console.log("[APPLE MUSIC RESOLVE] Resolving token:", sanitizedFilename);
    const payloadStr = downloadUrl.replace("applemusic_resolve:", "");

    try {
      let r4Data = null;
      const headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json, text/javascript, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        Origin: "https://aplmate.com",
        Referer: "https://aplmate.com/"
      };

      if (window.nimiyoEngine?.scraperFetch) {
        r4Data = await window.nimiyoEngine.scraperFetch({
          url: "https://aplmate.com/action/track",
          method: "POST",
          data: payloadStr,
          headers,
          rawResponse: true,
        }, "Aplmate Track Resolve");
      } else {
        const res = await fetch("https://aplmate.com/action/track", {
          method: "POST",
          headers,
          body: payloadStr,
        });
        r4Data = { data: await res.text() };
      }

      const trackHtml = r4Data?.data || r4Data;
      const parser = new DOMParser();
      const doc3 = parser.parseFromString(typeof trackHtml === "string" ? trackHtml : JSON.stringify(trackHtml), "text/html");

      let resolvedUrl = "";
      doc3.querySelectorAll("a").forEach((a) => {
        const href = a.getAttribute("href");
        const text = (a.textContent || "").trim();
        if (href && (href.includes("/dl?token=") || a.classList.contains("abutton"))) {
          if (href.includes("ko-fi.com") || href.includes("premium.html")) return;
          if (text.toLowerCase().includes("another song")) return;
          resolvedUrl = href.startsWith("http") ? href : "https://aplmate.com" + href;
        }
      });

      if (!resolvedUrl) {
        throw new Error("[NETWORK DOWNLOAD FAILED] Could not find download link in Aplmate response.");
      }
      downloadUrl = resolvedUrl;
    } catch (e) {
      console.error("[APPLE MUSIC RESOLVE] Error resolving token:", e);
      throw new Error(`[NETWORK DOWNLOAD FAILED] Apple Music resolve failed: ${e.message}`);
    }
  }


  return { url: downloadUrl, title: dlItem.title || null };
}
