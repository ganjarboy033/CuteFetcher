import { CHROME_UA } from "../utils/index.js";
import { scraperFetch, createScraperResult } from "./httpHelper.js";

const t = (key) =>
  typeof window.__t === "function"
    ? window.__t(key)
    : {
        "err-yt-playlist-source": "YouTube playlists require a supported server.",
      }[key] || key;

export let _ytSource = null;
export function setYouTubeSource(src) {
  _ytSource = src;
}

// Helper: Extract YouTube Video ID
export function extractYouTubeVideoId(url) {
  if (!url) return null;
  const match = url.match(
    /(?:youtube\.com\/(?:(?:v|e(?:mbed)?|shorts|live)\/|.*[?&]v=)|youtu\.be\/)([\w-]{11})/i
  );
  return match ? match[1] : null;
}

// Helper: Extract YouTube Playlist ID
export function extractYouTubePlaylistId(url) {
  if (!url) return null;
  const match = url.match(/[?&]list=([^"&?/\s]+)/i);
  return match ? match[1] : null;
}

// Helper: Fetch Video Metadata via oEmbed / Watch Page
async function fetchVideoMetadata(videoId) {
  let title = "YouTube Video";
  let thumbnail = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;

  try {
    const oData = await scraperFetch(
      {
        url: `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`,
      },
      "YouTube Oembed",
    );
    if (oData && oData.title) {
      title = oData.title;
      thumbnail = oData.thumbnail_url || thumbnail;
    }
  } catch (_) {}

  // Fallback: extract title from YouTube watch page HTML
  if (!title || title === "YouTube Video") {
    try {
      const pageHtml = await scraperFetch(
        {
          url: `https://www.youtube.com/watch?v=${videoId}`,
          headers: {
            "User-Agent": CHROME_UA,
            "Accept-Language": "en-US,en;q=0.9",
          },
        },
        "YouTube Watch Page",
      );
      if (typeof pageHtml === "string") {
        const m = pageHtml.match(/<title>(.*?)<\/title>/i);
        if (m && m[1]) {
          title = m[1].replace(/\s*-\s*YouTube\s*$/i, "").trim();
        }
      }
    } catch (_) {}
  }

  return { title: title || "YouTube Video", thumbnail };
}

// Convert via convert1s (media.ytmp3.gg API)
async function convertViaConvert1s(videoId, format = "mp4", quality = "720p") {
  const headers = {
    Origin: "https://media.ytmp3.gg",
    Referer: "https://media.ytmp3.gg/",
    "User-Agent": CHROME_UA,
    Accept: "application/json, text/plain, */*",
    "Content-Type": "application/json",
  };

  try {
    const convRes = await scraperFetch(
      {
        url: "https://hub.convert1s.com/api/download",
        method: "POST",
        headers,
        data: JSON.stringify({
          url: `https://www.youtube.com/watch?v=${videoId}`,
          os: "macos",
          output: {
            type: format === "mp4" ? "video" : "audio",
            format,
            quality: quality || (format === "mp4" ? "720p" : ""),
          },
          audio: { bitrate: "128k" },
        }),
        rawResponse: true,
      },
      "YTMP3 Convert",
    );

    let conv = convRes?.data;
    if (typeof conv === "string") {
      if (conv.trim().startsWith("<")) return null;
      try {
        conv = JSON.parse(conv);
      } catch (_) {
        return null;
      }
    }

    if (!conv || conv.error || !conv.statusUrl) return null;

    let downloadUrl = null;
    let attempts = 0;
    while (!downloadUrl && attempts < 12) {
      await new Promise((r) => setTimeout(r, 1200));
      const pollData = await scraperFetch(
        {
          url: conv.statusUrl,
          headers,
        },
        "YTMP3 Status",
      );
      attempts++;
      if (pollData && pollData.status === "completed" && pollData.downloadUrl) {
        downloadUrl = pollData.downloadUrl;
        break;
      }
      if (pollData && (pollData.status === "error" || pollData.status === "failed")) {
        break;
      }
    }

    if (downloadUrl) {
      return {
        url: downloadUrl,
        quality: conv.selectedQuality || quality || (format === "mp3" ? "Audio 128k" : "720p"),
        title: conv.title || null,
      };
    }
    return null;
  } catch (_) {
    return null;
  }
}

// Convert via ymcdn (ytmp3.mobi API with redirect loop resolution & cache-busting)
async function convertViaYmcdn(videoId, format = "mp4") {
  const headers = {
    Origin: "https://ytmp3.mobi",
    Referer: "https://ytmp3.mobi/en8/",
    "User-Agent": CHROME_UA,
    Accept: "*/*",
  };

  try {
    const initData = await scraperFetch(
      {
        url: `https://a.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`,
        headers,
      },
      "YTMobi Init",
    );

    if (!initData || !initData.convertURL) return null;

    let convData = await scraperFetch(
      {
        url: `${initData.convertURL}&v=${videoId}&f=${format}&_=${Math.random()}`,
        headers,
      },
      "YTMobi Convert",
    );

    // Follow redirect loop if server redirects to alternate cluster
    let redirAttempts = 0;
    while (convData && convData.redirect > 0 && convData.redirectURL && redirAttempts < 5) {
      redirAttempts++;
      convData = await scraperFetch(
        {
          url: `${convData.redirectURL}&v=${videoId}&f=${format}&_=${Math.random()}`,
          headers,
        },
        "YTMobi Redirect",
      );
    }

    if (!convData || convData.error) return null;

    let progress = convData.progress || 0;
    let dlUrl = convData.downloadURL || null;
    let progUrl = convData.progressURL;
    let attempts = 0;

    while (progress < 3 && attempts < 12 && progUrl) {
      await new Promise((r) => setTimeout(r, 1200));
      const progData = await scraperFetch(
        {
          url: `${progUrl}&_=${Math.random()}`,
          headers,
        },
        "YTMobi Progress",
      );
      if (!progData || progData.error) break;
      progress = progData.progress ?? 0;
      if (progData.downloadURL) dlUrl = progData.downloadURL;
      if (progress === 4) break;
      attempts++;
    }

    if (dlUrl && (progress >= 3 || dlUrl.includes("/download/"))) {
      if (dlUrl.startsWith("//")) dlUrl = "https:" + dlUrl;
      if (dlUrl.startsWith("/")) dlUrl = "https://ytmp3.mobi" + dlUrl;

      return {
        url: dlUrl,
        quality: format === "mp3" ? "MP3 320k" : "MP4 720p",
        title: convData.title || null,
      };
    }
    return null;
  } catch (_) {
    return null;
  }
}

// Playlist Extractor: Direct YouTube HTML + Fallback
async function extractPlaylist(playlistId, originalUrl) {
  let playlistTitle = "YouTube Playlist";
  let playlistThumbnail = "https://www.youtube.com/img/desktop/yt_1200.png";
  const items = [];

  // 1. Direct YouTube Playlist HTML Extraction
  try {
    const html = await scraperFetch(
      {
        url: `https://www.youtube.com/playlist?list=${playlistId}`,
        headers: {
          "User-Agent": CHROME_UA,
          "Accept-Language": "en-US,en;q=0.9",
          Cookie: "SOCS=CAESEwgDEgk2MTc4OTU0NzQaAmVuIAEaBgiA_LyaBg; CONSENT=PENDING+999",
        },
      },
      "YouTube Playlist Direct",
    );

    if (typeof html === "string" && html.length > 500) {
      let data = null;
      const marker = "ytInitialData = ";
      const idx = html.indexOf(marker);
      if (idx !== -1) {
        const start = idx + marker.length;
        const scriptEnd = html.indexOf("</script>", start);
        if (scriptEnd !== -1) {
          let rawStr = html.substring(start, scriptEnd).trim();
          if (rawStr.endsWith(";")) rawStr = rawStr.slice(0, -1);
          try {
            data = JSON.parse(rawStr);
          } catch (_) {}
        }
      }

      if (!data) {
        const m = html.match(/ytInitialData\s*=\s*({.+?});<\/script>/s);
        if (m) {
          try {
            data = JSON.parse(m[1]);
          } catch (_) {}
        }
      }

      if (data) {
        const parsedTitle =
          data.metadata?.playlistMetadataRenderer?.title ||
          data.header?.playlistHeaderRenderer?.title?.simpleText;
        if (parsedTitle) playlistTitle = parsedTitle;

        // Traverse video contents
        const tabs = data.contents?.twoColumnBrowseResultsRenderer?.tabs || [];
        const tabContent = tabs[0]?.tabRenderer?.content || {};
        const section =
          tabContent.sectionListRenderer?.contents?.[0]?.itemSectionRenderer?.contents?.[0];
        const plVideoList = section?.playlistVideoListRenderer?.contents || [];

        plVideoList.forEach((v) => {
          const rend = v.playlistVideoRenderer;
          if (!rend || !rend.videoId) return;
          const vid = rend.videoId;
          const vTitle = rend.title?.runs?.[0]?.text || "Track";
          const vChannel = rend.shortBylineText?.runs?.[0]?.text || "";
          const vThumb = rend.thumbnail?.thumbnails?.slice(-1)?.[0]?.url || `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`;
          items.push({
            id: vid,
            title: vTitle,
            channel: vChannel,
            thumbnail: vThumb,
          });
        });
      }
    }
  } catch (_) {}

  // 2. Fallback to API if direct HTML parsing yielded no items
  if (items.length === 0) {
    try {
      const plRes = await scraperFetch(
        {
          url: `https://yt-meta.convert1s.com/playlist?id=${playlistId}`,
          headers: {
            Origin: "https://media.ytmp3.gg",
            Referer: "https://media.ytmp3.gg/",
            "User-Agent": CHROME_UA,
          },
        },
        "YouTube Playlist API",
      );

      if (plRes && plRes.items && plRes.items.length > 0) {
        plRes.items.forEach((item) => {
          items.push({
            id: item.id,
            title: item.title,
            channel: item.channel || "",
            thumbnail: item.thumbnail || `https://i.ytimg.com/vi/${item.id}/hqdefault.jpg`,
          });
        });
        if (items[0]?.channel) {
          playlistTitle = `${items[0].channel} - YouTube Playlist`;
        }
      }
    } catch (_) {}
  }

  if (items.length === 0) {
    throw new Error("Failed to extract YouTube playlist. The playlist might be private or empty.");
  }

  const downloads = [];
  const padLen = String(items.length).length;
  items.forEach((item, index) => {
    const prefix = `${(index + 1).toString().padStart(padLen, "0")}. `;
    const trackLabel = item.channel ? `${item.channel} - ${item.title}` : item.title;
    downloads.push({
      type: `${prefix}${trackLabel}`,
      quality: "MP3",
      url: `ytmp3gg_resolve:${item.id}|||mp3|||128`,
      thumbnail: item.thumbnail,
      ext: "mp3",
    });
  });

  return createScraperResult(true, {
    title: playlistTitle,
    thumbnail: items[0]?.thumbnail || playlistThumbnail,
    downloads,
    sourceUrl: originalUrl,
  });
}

// Main YouTube Scraper Function
export async function scrapeYouTube(url) {
  let currentStatus = null;
  try {
    const videoId = extractYouTubeVideoId(url);
    const playlistId = extractYouTubePlaylistId(url);
    const isPlaylist = !!playlistId && !videoId;

    if (!videoId && !playlistId) {
      throw new Error("Invalid YouTube URL");
    }

    // Determine current active server: "auto" (default), "gg", or "mobi"
    let source = _ytSource || "auto";
    if (source === "direct" || source === "ytmp3") source = "auto";

    // Handle Playlists
    if (isPlaylist) {
      const plResult = await extractPlaylist(playlistId, url);
      _ytSource = null;
      return plResult;
    }

    // Fetch basic metadata
    const meta = await fetchVideoMetadata(videoId);
    const downloads = [];

    // Mode 1: Dedicated Server 2 (YTMP3.gg)
    if (source === "gg") {
      const [mp4, mp3] = await Promise.allSettled([
        convertViaConvert1s(videoId, "mp4", "720p"),
        convertViaConvert1s(videoId, "mp3", ""),
      ]);

      if (mp4.status === "fulfilled" && mp4.value?.url) {
        downloads.push({
          type: "MP4 720p",
          quality: mp4.value.quality || "720p",
          url: mp4.value.url,
        });
        if (mp4.value.title && (!meta.title || meta.title === "YouTube Video")) {
          meta.title = mp4.value.title;
        }
      }

      if (mp3.status === "fulfilled" && mp3.value?.url) {
        downloads.push({
          type: "MP3 Audio",
          quality: "128k",
          url: mp3.value.url,
        });
        if (mp3.value.title && (!meta.title || meta.title === "YouTube Video")) {
          meta.title = mp3.value.title;
        }
      }

      // If gg failed completely, fallback automatically to mobi
      if (downloads.length === 0) {
        console.warn("[YouTube] Server gg failed, cascading to mobi...");
        source = "mobi";
      }
    }

    // Mode 2: Dedicated Server 3 (YTMP3.mobi)
    if (source === "mobi") {
      const [mp4, mp3] = await Promise.allSettled([
        convertViaYmcdn(videoId, "mp4"),
        convertViaYmcdn(videoId, "mp3"),
      ]);

      if (mp4.status === "fulfilled" && mp4.value?.url) {
        downloads.push({
          type: "MP4 720p",
          quality: mp4.value.quality || "720p",
          url: mp4.value.url,
        });
        if (mp4.value.title && (!meta.title || meta.title === "YouTube Video")) {
          meta.title = mp4.value.title;
        }
      }

      if (mp3.status === "fulfilled" && mp3.value?.url) {
        downloads.push({
          type: "MP3 Audio",
          quality: "320k",
          url: mp3.value.url,
        });
        if (mp3.value.title && (!meta.title || meta.title === "YouTube Video")) {
          meta.title = mp3.value.title;
        }
      }
    }

    // Mode 3: Server 1 (Auto Fast Hybrid / Anti-Lag)
    if (source === "auto") {
      // Step A: Fire fast convert1s for video & audio in parallel
      const [ggMp4, ggMp3] = await Promise.allSettled([
        convertViaConvert1s(videoId, "mp4", "720p"),
        convertViaConvert1s(videoId, "mp3", ""),
      ]);

      if (ggMp4.status === "fulfilled" && ggMp4.value?.url) {
        downloads.push({
          type: "MP4 720p",
          quality: ggMp4.value.quality || "720p",
          url: ggMp4.value.url,
        });
        if (ggMp4.value.title && (!meta.title || meta.title === "YouTube Video")) {
          meta.title = ggMp4.value.title;
        }
      }

      if (ggMp3.status === "fulfilled" && ggMp3.value?.url) {
        downloads.push({
          type: "MP3 Audio",
          quality: "128k",
          url: ggMp3.value.url,
        });
        if (ggMp3.value.title && (!meta.title || meta.title === "YouTube Video")) {
          meta.title = ggMp3.value.title;
        }
      }

      // Step B: If any format failed or if convert1s was completely blocked, instantly use mobi
      const needMp4 = !downloads.some((d) => d.type.includes("MP4"));
      const needMp3 = !downloads.some((d) => d.type.includes("MP3"));

      if (needMp4 || needMp3) {
        const promises = [];
        if (needMp4) promises.push(convertViaYmcdn(videoId, "mp4"));
        else promises.push(Promise.resolve(null));

        if (needMp3) promises.push(convertViaYmcdn(videoId, "mp3"));
        else promises.push(Promise.resolve(null));

        const [mobiMp4, mobiMp3] = await Promise.allSettled(promises);

        if (needMp4 && mobiMp4.status === "fulfilled" && mobiMp4.value?.url) {
          downloads.push({
            type: "MP4 720p",
            quality: mobiMp4.value.quality || "720p",
            url: mobiMp4.value.url,
          });
          if (mobiMp4.value.title && (!meta.title || meta.title === "YouTube Video")) {
            meta.title = mobiMp4.value.title;
          }
        }

        if (needMp3 && mobiMp3.status === "fulfilled" && mobiMp3.value?.url) {
          downloads.push({
            type: "MP3 Audio",
            quality: "320k",
            url: mobiMp3.value.url,
          });
          if (mobiMp3.value.title && (!meta.title || meta.title === "YouTube Video")) {
            meta.title = mobiMp3.value.title;
          }
        }
      }
    }

    if (downloads.length === 0) {
      throw new Error("Failed to get YouTube download links. Please try another server.");
    }

    _ytSource = null;
    return createScraperResult(true, {
      ...meta,
      downloads,
      sourceUrl: url,
    });
  } catch (err) {
    _ytSource = null;
    return createScraperResult(false, err.message, currentStatus);
  }
}
