import { CHROME_UA, cleanUrl } from "../utils/index.js";
import { scraperFetch, createScraperResult } from "./httpHelper.js";

export let _scSource = null;
export function setSoundCloudSource(source) {
  _scSource = source;
}

/**
 * Scraper for SoundCloud Tracks & Audio
 * Primary: Forhub Engine (https://www.forhub.io)
 * Secondary: Klickaud Engine (https://www.klickaud.org)
 * Fallback: SoundCloud Official api-v2 Progressive Stream
 */
export async function scrapeSoundCloud(url) {
  let targetUrl = cleanUrl(url);

  // 1. Resolve short links (on.soundcloud.com, soundcloud.app.goo.gl)
  if (/on\.soundcloud\.com/i.test(targetUrl) || /soundcloud\.app\.goo\.gl/i.test(targetUrl)) {
    try {
      const resolveRes = await scraperFetch(
        {
          url: targetUrl,
          rawResponse: true,
          headers: {
            "User-Agent": CHROME_UA,
          },
        },
        "SoundCloud Short Resolver",
      );

      if (resolveRes.url && !/on\.soundcloud\.com/i.test(resolveRes.url)) {
        targetUrl = cleanUrl(resolveRes.url);
      } else if (resolveRes.headers?.location || resolveRes.headers?.Location) {
        targetUrl = cleanUrl(resolveRes.headers.location || resolveRes.headers.Location);
      } else if (typeof resolveRes.data === "string") {
        const canonical = resolveRes.data.match(/<link\s+rel=["']canonical["']\s+href=["']([^"']+)["']/i);
        const ogUrl = resolveRes.data.match(/<meta\s+property=["']og:url["']\s+content=["']([^"']+)["']/i);
        if (canonical && canonical[1]) {
          targetUrl = cleanUrl(canonical[1]);
        } else if (ogUrl && ogUrl[1]) {
          targetUrl = cleanUrl(ogUrl[1]);
        }
      }
    } catch (e) {
      console.warn("Failed to resolve SoundCloud short link:", e);
    }
  }

  // Strip tracking and playlist query params so clean track URL is passed
  if (targetUrl.includes("soundcloud.com/") && targetUrl.includes("?")) {
    try {
      const u = new URL(targetUrl);
      targetUrl = `${u.origin}${u.pathname}`;
    } catch (_) {}
  }

  // 2. oEmbed metadata helper
  let oembedMeta = null;
  try {
    const oembedRes = await scraperFetch(
      {
        url: `https://soundcloud.com/oembed?url=${encodeURIComponent(targetUrl)}&format=json`,
        parseJson: true,
      },
      "SoundCloud oEmbed",
    );
    if (oembedRes && oembedRes.title) {
      oembedMeta = oembedRes;
    }
  } catch (_) {}

  const source = _scSource || "forhub";
  _scSource = null;

  if (source === "direct") {
    try {
      return await scrapeSoundCloudDirect(targetUrl, oembedMeta);
    } catch (directErr) {
      console.warn("Direct failed, trying Forhub:", directErr.message);
      try {
        return await scrapeForhubEngine(targetUrl, oembedMeta);
      } catch (forhubErr) {
        return await scrapeKlickaudEngine(targetUrl, oembedMeta);
      }
    }
  } else if (source === "klickaud") {
    try {
      return await scrapeKlickaudEngine(targetUrl, oembedMeta);
    } catch (klickErr) {
      console.warn("Klickaud failed, trying Forhub:", klickErr.message);
      try {
        return await scrapeForhubEngine(targetUrl, oembedMeta);
      } catch (forhubErr) {
        return await scrapeSoundCloudDirect(targetUrl, oembedMeta);
      }
    }
  } else {
    // Primary: Forhub (Fast, Direct REST JSON, No SSE / cookie dependencies)
    try {
      return await scrapeForhubEngine(targetUrl, oembedMeta);
    } catch (forhubErr) {
      console.warn("Forhub failed, trying Klickaud backup:", forhubErr.message);
      try {
        return await scrapeKlickaudEngine(targetUrl, oembedMeta);
      } catch (klickErr) {
        console.warn("Klickaud failed, trying Direct SoundCloud fallback:", klickErr.message);
        try {
          return await scrapeSoundCloudDirect(targetUrl, oembedMeta);
        } catch (directErr) {
          return createScraperResult(false, `SoundCloud error: ${forhubErr.message} (Klickaud: ${klickErr.message}, Direct: ${directErr.message})`);
        }
      }
    }
  }
}

/**
 * Clean metadata titles of platform suffixes
 */
function sanitizeTrackTitle(raw) {
  return (raw || "")
    .replace(/_forhub_soundcloud_to_mp3/gi, "")
    .replace(/_KLICKAUD/gi, "")
    .replace(/\.mp3$/i, "")
    .replace(/_+/g, " ")
    .trim();
}

/**
 * Engine 1: Forhub (REST JSON with X-Forhub-Api-Token)
 */
async function scrapeForhubEngine(url, oembedMeta) {
  const baseDomain = "https://www.forhub.io";
  const homeUrl = `${baseDomain}/soundcloud/en18/`;
  const ua = CHROME_UA;

  // 1. Obtain CSRF Token
  const tokenRes = await scraperFetch(
    {
      url: `${baseDomain}/csrf-token-endpoint.php`,
      headers: {
        "User-Agent": ua,
        Referer: homeUrl,
        Accept: "application/json",
      },
      rawResponse: true,
    },
    "Forhub CSRF",
  );

  let tokenData = tokenRes.data;
  if (typeof tokenData === "string") {
    try { tokenData = JSON.parse(tokenData); } catch (_) {}
  }

  const csrfToken = tokenData?.csrf_token;
  if (!csrfToken) {
    throw new Error("Could not obtain security token from Forhub.");
  }

  // 2. Submit track URL to obtain API token
  const params = new URLSearchParams();
  params.append("formurl", url);
  params.append("value", url);
  params.append("csrf_token", csrfToken);

  const postRes = await scraperFetch(
    {
      url: `${baseDomain}/download.php`,
      method: "POST",
      data: params.toString(),
      headers: {
        "User-Agent": ua,
        Referer: homeUrl,
        Origin: baseDomain,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      rawResponse: true,
    },
    "Forhub Submit",
  );

  const html = typeof postRes.data === "string" ? postRes.data : "";
  const tokenMatch = html.match(/const\s+FORHUB_API_TOKEN\s*=\s*["']([^"']+)["']/);
  const forhubApiToken = tokenMatch ? tokenMatch[1] : null;

  if (!forhubApiToken) {
    const alertMatch = html.match(/class=["'][^"']*alert[^"']*["'][^>]*>([\s\S]*?)<\/div>/i);
    if (alertMatch) {
      throw new Error(alertMatch[1].replace(/<[^>]+>/g, "").trim());
    }
    throw new Error("Forhub could not authorize this track conversion.");
  }

  // 3. Initiate download from dl.forhub.io
  const dlEndpoint = `https://dl.forhub.io/?url=${encodeURIComponent(url)}&async=1`;
  const reqHeaders = {
    "User-Agent": ua,
    "X-Forhub-Api-Token": forhubApiToken,
    Accept: "application/json, text/plain, */*",
    Referer: `${baseDomain}/download.php`,
    Origin: baseDomain,
  };

  let dlRes = await scraperFetch(
    {
      url: dlEndpoint,
      headers: reqHeaders,
      rawResponse: true,
    },
    "Forhub DL Request",
  );

  let data = dlRes.data;
  if (typeof data === "string") {
    try { data = JSON.parse(data); } catch (_) {}
  }

  // Handle 202 async conversion poll
  let pollAttempts = 0;
  const maxPolls = 15;
  while ((dlRes.status === 202 || data?.pending) && data?.pollToken && pollAttempts < maxPolls) {
    await new Promise((r) => setTimeout(r, 2000));
    const pollRes = await scraperFetch(
      {
        url: "https://dl.forhub.io/status",
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "User-Agent": ua,
          Referer: `${baseDomain}/download.php`,
          Origin: baseDomain,
        },
        data: JSON.stringify({ token: data.pollToken }),
        rawResponse: true,
      },
      "Forhub Poll",
    );
    data = pollRes.data;
    if (typeof data === "string") {
      try { data = JSON.parse(data); } catch (_) {}
    }
    pollAttempts++;
    if (data?.success && data?.downloadUrl) break;
  }

  if (!data || !data.downloadUrl) {
    throw new Error(data?.message || "Forhub could not generate an MP3 download link for this track.");
  }

  const resolvedTitle = data.metadata?.title || (data.Originalfilename ? sanitizeTrackTitle(data.Originalfilename) : null) || oembedMeta?.title || "SoundCloud Track";
  const resolvedThumbnail = data.metadata?.thumbnail || oembedMeta?.thumbnail_url || null;

  return createScraperResult(true, {
    title: resolvedTitle,
    author: oembedMeta?.author_name || "SoundCloud",
    thumbnail: resolvedThumbnail,
    downloads: [
      {
        type: "MP3 (128kbps)",
        quality: "128kbps MP3",
        url: data.downloadUrl,
        headers: {
          Referer: `${baseDomain}/download.php`,
          "User-Agent": ua,
        },
      },
    ],
    sourceUrl: url,
  });
}

/**
 * Engine 2: Klickaud Engine
 */
async function scrapeKlickaudEngine(url, oembedMeta) {
  const baseDomain = "https://www.klickaud.org";
  const homeReferer = `${baseDomain}/en17/`;
  const ua = CHROME_UA;

  // Step 1: Obtain CSRF token
  const tokenRes = await scraperFetch(
    {
      url: `${baseDomain}/csrf-token-endpoint.php`,
      headers: {
        "User-Agent": ua,
        Referer: homeReferer,
        Accept: "application/json",
      },
      rawResponse: true,
    },
    "Klickaud CSRF",
  );

  let tokenData = tokenRes.data;
  if (typeof tokenData === "string") {
    try { tokenData = JSON.parse(tokenData); } catch (_) {}
  }

  const csrfToken = tokenData?.csrf_token;
  if (!csrfToken) {
    throw new Error("Failed to obtain security token from Klickaud.");
  }

  // Step 2: Submit track URL
  const params = new URLSearchParams();
  params.append("value", url);
  params.append("csrf_token", csrfToken);

  const postRes = await scraperFetch(
    {
      url: `${baseDomain}/download.php`,
      method: "POST",
      data: params.toString(),
      headers: {
        "User-Agent": ua,
        Referer: homeReferer,
        Origin: baseDomain,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      rawResponse: true,
    },
    "Klickaud Submit",
  );

  const html = typeof postRes.data === "string" ? postRes.data : "";
  const downloadMode = (html.match(/const\s+downloadMode\s*=\s*["']([^"']+)["']/) || [])[1];
  const directUrl = (html.match(/const\s+directDownloadUrl\s*=\s*["']([^"']*)["']/) || [])[1];
  const defaultFileName = (html.match(/const\s+defaultFileName\s*=\s*["']([^"']+)["']/) || [])[1] || "SoundCloud Track";
  const sseGrant = (html.match(/const\s+sseGrant\s*=\s*["']([^"']+)["']/) || [])[1];

  let resolvedTitle = oembedMeta?.title || sanitizeTrackTitle(defaultFileName);
  let resolvedThumbnail = oembedMeta?.thumbnail_url || null;

  // Direct download mode
  if (downloadMode === "direct" && directUrl) {
    return createScraperResult(true, {
      title: resolvedTitle,
      author: oembedMeta?.author_name || "SoundCloud",
      thumbnail: resolvedThumbnail,
      downloads: [
        {
          type: "MP3 (128kbps)",
          quality: "128kbps MP3",
          url: directUrl,
          headers: {
            Referer: `${baseDomain}/download.php`,
            "User-Agent": ua,
          },
        },
      ],
      sourceUrl: url,
    });
  }

  if (!sseGrant) {
    throw new Error("Could not retrieve download session grant from Klickaud.");
  }

  // Capability authorization
  const capRes = await scraperFetch(
    {
      url: `${baseDomain}/sse_capability.php`,
      method: "POST",
      data: { grant: sseGrant, url },
      headers: {
        "User-Agent": ua,
        Referer: `${baseDomain}/download.php`,
        Origin: baseDomain,
        "Content-Type": "application/json",
      },
      rawResponse: true,
    },
    "Klickaud Capability",
  );

  let capData = capRes.data;
  if (typeof capData === "string") {
    try { capData = JSON.parse(capData); } catch (_) {}
  }

  const capability = capData?.capability;
  if (!capability) {
    throw new Error("Could not authorize download capability from Klickaud.");
  }

  const sseUrl = `${baseDomain}/worker_sse.php?url=${encodeURIComponent(url)}&cap=${encodeURIComponent(capability)}`;
  const sseRes = await scraperFetch(
    {
      url: sseUrl,
      headers: {
        "User-Agent": ua,
        Referer: `${baseDomain}/download.php`,
        Accept: "text/event-stream",
      },
      rawResponse: true,
      parseJson: false,
    },
    "Klickaud Worker SSE",
  );

  const sseData = typeof sseRes.data === "string" ? sseRes.data : JSON.stringify(sseRes.data);
  if (sseData.includes("event: failed")) {
    throw new Error("Worker failed to process this track. Track may be copyright restricted.");
  }

  const readyMatch = sseData.match(/event:\s*ready[\r\n]+data:\s*([^\r\n]+)/i) ||
                     sseData.match(/data:\s*({[^\n]+download_url[^\n]+})/i);
  let parsedPayload = null;
  if (readyMatch) {
    try {
      parsedPayload = JSON.parse(readyMatch[1]);
    } catch (_) {}
  }

  if (parsedPayload?.download_url) {
    const finalTitle = parsedPayload.metadata?.title || (parsedPayload.file_name ? sanitizeTrackTitle(parsedPayload.file_name) : resolvedTitle);
    const finalThumb = parsedPayload.metadata?.thumbnail || resolvedThumbnail;

    return createScraperResult(true, {
      title: finalTitle,
      author: oembedMeta?.author_name || "SoundCloud",
      thumbnail: finalThumb,
      downloads: [
        {
          type: "MP3 (128kbps)",
          quality: "128kbps MP3",
          url: parsedPayload.download_url,
          headers: {
            Referer: `${baseDomain}/download.php`,
            "User-Agent": ua,
          },
        },
      ],
      sourceUrl: url,
    });
  }

  throw new Error("Download stream ended without producing a download URL.");
}

/**
 * Engine 3: SoundCloud Official api-v2 Stream Extractor
 */
async function scrapeSoundCloudDirect(url, oembedMeta) {
  const ua = CHROME_UA;
  const CLIENT_IDS = [
    "3GKD969NJWD1eB6gvQJN0GnueYbcWszv",
    "2t9loNfh0ekOfjhUJywOcvwPwsqPvdca",
    "a3e059563d7fd3372b49b37f00a00bcf",
  ];

  let lastErr = null;
  for (const clientId of CLIENT_IDS) {
    try {
      const resolveUrl = `https://api-v2.soundcloud.com/resolve?url=${encodeURIComponent(url)}&client_id=${clientId}`;
      const apiRes = await scraperFetch(
        {
          url: resolveUrl,
          parseJson: true,
          headers: { "User-Agent": ua },
        },
        "SoundCloud api-v2 Resolve",
      );

      if (!apiRes || !apiRes.media?.transcodings) {
        continue;
      }

      const title = apiRes.title || oembedMeta?.title || "SoundCloud Track";
      const author = apiRes.user?.username || oembedMeta?.author_name || "SoundCloud";
      const thumbnail = apiRes.artwork_url || oembedMeta?.thumbnail_url || null;

      const downloads = [];
      for (const t of apiRes.media.transcodings) {
        try {
          const streamInfo = await scraperFetch(
            {
              url: `${t.url}?client_id=${clientId}`,
              parseJson: true,
              headers: { "User-Agent": ua },
            },
            "SoundCloud Stream",
          );
          if (streamInfo?.url) {
            const isProgressive = t.format?.protocol === "progressive";
            downloads.push({
              type: isProgressive ? "MP3 (Original Direct)" : "Audio Stream (AAC / HLS)",
              quality: isProgressive ? "128kbps MP3" : (t.format?.mime_type || "160kbps"),
              url: streamInfo.url,
            });
          }
        } catch (_) {}
      }

      // Prioritize progressive streams over HLS
      const progressiveOnly = downloads.filter((d) => d.type.includes("MP3"));
      const finalDownloads = progressiveOnly.length > 0 ? progressiveOnly : downloads;

      if (finalDownloads.length > 0) {
        return createScraperResult(true, {
          title,
          author,
          thumbnail,
          downloads: finalDownloads,
          sourceUrl: url,
        });
      }
    } catch (e) {
      lastErr = e;
    }
  }

  throw new Error(lastErr?.message || "No playable audio streams could be retrieved from SoundCloud.");
}
