import { CHROME_UA, getCookiesFromHeaders } from "../utils/index.js";
import { getCleanUrl } from "../utils/urlUtils.js";
import { scraperFetch, createScraperResult } from "./httpHelper.js";

async function decryptSnapTikAes(id, encryptedBase64) {
  const salt = "sn4pt1k_v3r1fy2026";
  const str = salt + ":" + id;
  const encoder = new TextEncoder();
  const keyBytes = await window.crypto.subtle.digest(
    "SHA-256",
    encoder.encode(str),
  );

  const binaryString = atob(encryptedBase64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  const iv = bytes.slice(0, 16);
  const data = bytes.slice(16);

  const cryptoKey = await window.crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "AES-CBC" },
    false,
    ["decrypt"],
  );

  const decryptedBuffer = await window.crypto.subtle.decrypt(
    { name: "AES-CBC", iv },
    cryptoKey,
    data,
  );

  return new TextDecoder().decode(decryptedBuffer);
}

function solveSnapTikChallenge(challenge) {
  switch (challenge.t) {
    case "b":
      return ((challenge.a ^ challenge.b) >> challenge.s) & 255;
    case "r":
      return challenge.n.reduce((m, f) => m + f, 0) * 2 + 1;
    case "c":
      return challenge.w.charCodeAt(challenge.i) * challenge.m;
    case "m":
      return ((challenge.a + challenge.b) % 100) * challenge.c;
    case "n":
      return (
        challenge.a * challenge.b +
        challenge.b * challenge.c +
        challenge.c * challenge.a -
        challenge.a
      );
    default:
      throw new Error("Unknown challenge type: " + challenge.t);
  }
}

export let _ttSource = null;
export function setTikTokSource(src) {
  _ttSource = src;
}

export async function scrapeTikTok(url) {
  let currentStatus = null;
  try {
    const cleanUrl = getCleanUrl(url).split("?")[0];
    const regexTiktokUrl =
      /https:\/\/(?:m|www|vm|vt|lite)?\.?tiktok\.com\/((?:.*\b(?:(?:usr|v|embed|user|video|photo)\/|\?shareId=|\&item_id=)(\d+))|\w+)/;
    if (!regexTiktokUrl.test(cleanUrl)) {
      throw new Error("Must be a valid tiktok url.");
    }

    if (!_ttSource) return { requireSource: true };

    if (_ttSource === "snaptik") {
      const tokenRes = await scraperFetch(
        {
          url: "https://snaptik.app/api/token",
          method: "POST",
          headers: {
            "User-Agent": CHROME_UA,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/json",
            Origin: "https://snaptik.app",
            Referer: "https://snaptik.app/",
          },
          data: {},
          rawResponse: true,
        },
        "SnapTik Token",
      );
      currentStatus = tokenRes.status;
      const tData =
        typeof tokenRes.data === "string"
          ? JSON.parse(tokenRes.data)
          : tokenRes.data;
      if (!tData || !tData.id || !tData.p)
        throw new Error("Failed to retrieve token from SnapTik API.");

      const decryptedStr = await decryptSnapTikAes(tData.id, tData.p);
      const challenge = JSON.parse(decryptedStr);
      const _e = challenge._e;
      const _h = challenge._h;
      delete challenge._e;
      delete challenge._h;
      const challengeResult = solveSnapTikChallenge(challenge);
      const xVerify = `${tData.id}:${challengeResult}:${_e}:${_h}`;

      const extractRes = await scraperFetch(
        {
          url: `https://snaptik.app/api/extract?url=${encodeURIComponent(cleanUrl)}`,
          headers: {
            "User-Agent": CHROME_UA,
            "X-Requested-With": "XMLHttpRequest",
            "X-Verify": xVerify,
            Origin: "https://snaptik.app",
            Referer: "https://snaptik.app/",
          },
          rawResponse: true,
        },
        "SnapTik Extract",
      );
      currentStatus = extractRes.status;
      const exData =
        typeof extractRes.data === "string"
          ? JSON.parse(extractRes.data)
          : extractRes.data;
      if (!exData || !exData.success || !exData.data) {
        throw new Error(exData?.message || "SnapTik extraction failed.");
      }

      const info = exData.data;
      const downloads = [];

      const photos =
        info.photoUrls || info.photos || info.images || info.slides;
      if (photos && Array.isArray(photos) && photos.length > 0) {
        photos.forEach((img, idx) => {
          const photoUrl =
            typeof img === "string"
              ? img
              : img?.url || img?.src || img?.link || img?.downloadUrl || "";
          if (photoUrl) {
            const ext = (photoUrl.toLowerCase().includes(".png") || photoUrl.toLowerCase().includes("format=png")) ? "PNG" : "JPG";
            downloads.push({
              type: `IMAGE (${ext})`,
              url: photoUrl,
              itemIndex: idx + 1,
              totalItems: photos.length
            });
          }
        });
      }

      if (info.downloadUrl) {
        downloads.push({ type: "MP4", url: info.downloadUrl });
      }
      if (info.hdDownloadUrl) {
        const hdUrl = info.hdDownloadUrl.startsWith("http")
          ? info.hdDownloadUrl
          : "https://snaptik.app" + info.hdDownloadUrl;
        downloads.push({ type: "MP4 (HD)", url: hdUrl });
      }

      if (!downloads.length)
        throw new Error("No download links found from SnapTik.");

      _ttSource = null;
      return createScraperResult(true, {
        title: info.title || "TikTok Video",
        author: info.author?.nickname || info.author?.name || "TikTok User",
        thumbnail: info.thumbnail || "",
        downloads,
        sourceUrl: url,
      });
    }

    if (_ttSource === "tiktokio") {
      const res = await scraperFetch(
        {
          url: "https://tiktokio.com/api/v1/tk/html",
          method: "POST",
          data: {
            vid: cleanUrl,
            prefix: "tiktokio.com",
          },
          headers: {
            "User-Agent": CHROME_UA,
            "Content-Type": "application/json",
            Origin: "https://tiktokio.com",
            Referer: "https://tiktokio.com/",
          },
          rawResponse: true,
        },
        "TikTokIO",
      );
      currentStatus = res.status;

      let html = res.data;
      if (typeof html === "object" && html !== null) {
        html = JSON.stringify(html);
      }
      if (typeof html !== "string") {
        html = "";
      }
      if (
        !html ||
        html.includes("Please paste a valid link") ||
        html.includes("Error")
      ) {
        throw new Error("Invalid link or failed to fetch data from tiktokio.");
      }

      let title = "TikTok Content";
      const titleMatch = html.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
      if (titleMatch) {
        title = titleMatch[1].replace(/<[^>]+>/g, "").trim();
      }

      let thumbnail = "";
      const thumbMatch = html.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
      if (thumbMatch) {
        thumbnail = thumbMatch[1].replace(/&#38;/g, "&");
      }

      const isSlideshow =
        html.includes('class="images-grid"') ||
        html.includes('class="image-item"');

      const authorMatch = cleanUrl.match(/@([^\/]+)/);
      const author = authorMatch ? authorMatch[1] : "Unknown";

      const downloads = [];

      if (isSlideshow) {
        const slidesRegex =
          /<div[^>]*class=["'][^"']*image-item[^"']*["'][^>]*>[\s\S]*?<\/div>/gi;
        let slideMatch;
        let photoIdx = 0;
        while ((slideMatch = slidesRegex.exec(html)) !== null) {
          const slideHtml = slideMatch[0];
          const aHref = slideHtml.match(/href=["']([^"']+)/i);
          if (aHref && aHref[1] !== "#") {
            const photoUrl = aHref[1].replace(/&#38;/g, "&");
            if (!downloads.some((d) => d.url === photoUrl)) {
              photoIdx++;
              const ext = (photoUrl.toLowerCase().includes(".png") || photoUrl.toLowerCase().includes("format=png")) ? "PNG" : "JPG";
              downloads.push({
                type: `IMAGE (${ext})`,
                url: photoUrl,
                isMirror: false,
                itemIndex: photoIdx
              });
            }
          } else {
            const imgSrc = slideHtml.match(/src=["']([^"']+)/i);
            if (imgSrc) {
              const photoUrl = imgSrc[1].replace(/&#38;/g, "&");
              if (!downloads.some((d) => d.url === photoUrl)) {
                photoIdx++;
                const ext = (photoUrl.toLowerCase().includes(".png") || photoUrl.toLowerCase().includes("format=png")) ? "PNG" : "JPG";
                downloads.push({
                  type: `IMAGE (${ext})`,
                  url: photoUrl,
                  isMirror: false,
                  itemIndex: photoIdx
                });
              }
            }
          }
        }

        const mp3TagRegex = /<a[\s\S]*?<\/a>/gi;
        let mp3Match;
        while ((mp3Match = mp3TagRegex.exec(html)) !== null) {
          const tag = mp3Match[0];
          if (
            tag.includes("download-btn-purple") ||
            tag.toLowerCase().includes("mp3") ||
            tag.toLowerCase().includes("music")
          ) {
            const h = tag.match(/href=["']([^"']+)/i);
            if (h && h[1] !== "#") {
              const audioUrl = h[1].replace(/&#38;/g, "&");
              if (!downloads.some((d) => d.url === audioUrl)) {
                downloads.push({ type: "MP3", url: audioUrl, isMirror: false });
              }
            }
          }
        }
      } else {
        const anchorTagRegex = /<a[\s\S]*?<\/a>/gi;
        let anchorMatch;
        while ((anchorMatch = anchorTagRegex.exec(html)) !== null) {
          const tag = anchorMatch[0];

          if (!tag.includes("download-btn")) continue;

          const hrefM = tag.match(/href=["']([^"']+)/i);
          if (!hrefM || hrefM[1] === "#") continue;
          const href = hrefM[1].replace(/&#38;/g, "&");

          const innerText = tag
            .replace(/<[^>]+>/g, "")
            .trim()
            .toLowerCase();

          let label = null;
          if (
            innerText.includes("without watermark") ||
            tag.includes("download-btn-blue") ||
            tag.includes("download-btn-green")
          ) {
            label = "VIDEO";
          } else if (
            innerText.includes("mp3") ||
            innerText.includes("music") ||
            tag.includes("download-btn-purple")
          ) {
            label = "MP3";
          }

          if (label) {
            const isMirror = downloads.some((d) => d.type === label);
            downloads.push({ type: label, url: href, isMirror });
          }
        }
      }

      if (downloads.length === 0) {
        throw new Error("No download links found.");
      }

      _ttSource = null;
      return createScraperResult(true, {
        title,
        author,
        thumbnail,
        downloads,
        sourceUrl: url,
      });
    }

    if (_ttSource === "ssstik") {
      const BASE = "https://ssstik.io";
      const r1 = await scraperFetch(
        {
          url: BASE + "/id",
          headers: {
            "User-Agent": CHROME_UA,
            Referer: BASE + "/id",
          },
          rawResponse: true,
        },
        "SSSTik Home",
      );
      currentStatus = r1.status;
      const html1 = typeof r1.data === "string" ? r1.data : String(r1.data || "");
      const cookies = getCookiesFromHeaders(r1.headers);

      const tokenMatch = html1.match(/s_tt\s*=\s*'([^']+)'/);
      if (!tokenMatch || !tokenMatch[1]) {
        throw new Error("Can't find session token on ssstik.");
      }
      const token = tokenMatch[1];

      const formData = new URLSearchParams();
      formData.append("id", cleanUrl);
      formData.append("locale", "id");
      formData.append("tt", token);

      const postHeaders = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "HX-Request": "true",
        "HX-Trigger": "submit",
        "HX-Target": "target",
        "User-Agent": CHROME_UA,
        Referer: BASE + "/id",
        Origin: BASE,
      };
      if (cookies) postHeaders["Cookie"] = cookies;

      const r2 = await scraperFetch(
        {
          url: BASE + "/abc?url=dl",
          method: "POST",
          data: formData.toString(),
          headers: postHeaders,
          rawResponse: true,
        },
        "SSSTik Extract",
      );
      currentStatus = r2.status;

      const html2 = typeof r2.data === "string" ? r2.data : String(r2.data || "");
      if (
        !html2 ||
        html2.includes("Please paste a valid link") ||
        html2.includes("Error")
      ) {
        throw new Error("Invalid link or failed to fetch data from ssstik.");
      }

      const parser = new DOMParser();
      const doc = parser.parseFromString(html2, "text/html");

      const title =
        doc.querySelector("p.maintext")?.textContent?.trim() ||
        doc.querySelector("h2")?.textContent?.trim() ||
        "TikTok Content";
      const author =
        doc.querySelector("h2")?.textContent?.trim() || "TikTok User";
      const thumbnail =
        doc.querySelector("img.result_author")?.getAttribute("src") || "";

      const downloads = [];
      const slides = doc.querySelectorAll("a.slide, a.download_slide");

      if (slides.length > 0 || doc.querySelector("ul.splide__list")) {
        slides.forEach((el, idx) => {
          const href = el.getAttribute("href");
          if (!href) return;
          const ext = (href.toLowerCase().includes(".png") || href.toLowerCase().includes("format=png")) ? "PNG" : "JPG";
          downloads.push({
            type: `IMAGE (${ext})`,
            url: href,
            isMirror: false,
            itemIndex: idx + 1,
            totalItems: slides.length
          });
        });
        const musicHref = doc.querySelector("a.music")?.getAttribute("href");
        if (musicHref && !downloads.some((d) => d.url === musicHref)) {
          downloads.push({ type: "MP3", url: musicHref, isMirror: false });
        }
      } else {
        doc.querySelectorAll("a").forEach((el) => {
          const href = el.getAttribute("href");
          const text = (el.textContent || "").trim().toLowerCase();
          const hasWmClass = el.classList.contains("without_watermark");
          const isMusicClass = el.classList.contains("music");

          if (href && href !== "/" && !href.includes("snaptik")) {
            if (
              hasWmClass ||
              text.includes("tanpa tanda air") ||
              text.includes("without watermark")
            ) {
              const isMirror = downloads.some((d) => d.type === "MP4" || d.type === "VIDEO");
              downloads.push({ type: "MP4", url: href, isMirror });
            } else if (
              isMusicClass ||
              text.includes("mp3") ||
              text.includes("music")
            ) {
              const isMirror = downloads.some((d) => d.type === "MP3");
              downloads.push({ type: "MP3", url: href, isMirror });
            }
          }
        });

        if (downloads.length === 0) {
          doc.querySelectorAll("a.pure-button").forEach((el) => {
            const href = el.getAttribute("href");
            if (href && href.includes("dl=")) {
              downloads.push({ type: "MP4", url: href, isMirror: false });
            }
          });
        }
      }

      if (downloads.length === 0) {
        throw new Error("No download links found from ssstik.");
      }

      _ttSource = null;
      return createScraperResult(true, {
        title,
        author,
        thumbnail,
        downloads,
        sourceUrl: url,
      });
    }

    if (_ttSource === "tikdownloader") {
      const BASE = "https://tikdownloader.io";
      const payload = `q=${encodeURIComponent(cleanUrl)}&vt=id`;
      const postHeaders = {
        "User-Agent": CHROME_UA,
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        Origin: BASE,
        Referer: BASE + "/id",
      };

      const res = await scraperFetch(
        {
          url: BASE + "/api/ajaxSearch",
          method: "POST",
          data: payload,
          headers: postHeaders,
          rawResponse: true,
        },
        "TikDownloader Extract",
      );
      currentStatus = res.status;

      let json = res.data;
      if (typeof json === "string") {
        try { json = JSON.parse(json); } catch (_) {}
      }

      if (!json || json.status !== "ok" || !json.data) {
        throw new Error(json?.msg || "TikDownloader extraction failed.");
      }

      const parser = new DOMParser();
      const doc = parser.parseFromString(json.data, "text/html");

      const title =
        doc.querySelector(".clearfix h3")?.textContent?.trim() ||
        doc.querySelector("h3")?.textContent?.trim() ||
        "TikTok Content";
      const thumbnail =
        doc.querySelector(".image-tik img")?.getAttribute("src") ||
        doc.querySelector("img")?.getAttribute("src") ||
        "";

      const authorMatch = cleanUrl.match(/@([^\/]+)/);
      const author = authorMatch ? authorMatch[1] : "TikTok User";

      const downloads = [];

      doc.querySelectorAll("a.tik-button-dl").forEach((a) => {
        const href = a.getAttribute("href");
        if (!href) return;
        const text = (a.textContent || "").trim().toLowerCase();

        if (text.includes("mp4 hd") || text.includes("hd")) {
          downloads.push({ type: "MP4 (HD)", url: href, quality: "1080p" });
        } else if (
          text.includes("mp4 [1]") ||
          text.includes("without watermark") ||
          text.includes("mp4")
        ) {
          downloads.push({ type: "MP4", url: href, quality: "720p" });
        } else if (text.includes("mp4 [2]")) {
          downloads.push({
            type: "MP4",
            url: href,
            quality: "720p",
            isMirror: true,
          });
        } else if (text.includes("mp3") || text.includes("audio")) {
          downloads.push({ type: "MP3", url: href, quality: "MP3" });
        } else if (text.includes("photo") || text.includes("image")) {
          const ext = (href.toLowerCase().includes(".png") || href.toLowerCase().includes("format=png")) ? "PNG" : "JPG";
          downloads.push({ type: `IMAGE (${ext})`, url: href, quality: "photo" });
        }
      });

      doc.querySelectorAll(".image-item img, .photo-item img").forEach((img, idx) => {
        const src = img.getAttribute("src");
        if (src && !downloads.some((d) => d.url === src)) {
          const ext = (src.toLowerCase().includes(".png") || src.toLowerCase().includes("format=png")) ? "PNG" : "JPG";
          downloads.push({
            type: `IMAGE (${ext})`,
            url: src,
            itemIndex: idx + 1
          });
        }
      });

      if (downloads.length === 0) {
        throw new Error("No download links found from TikDownloader.");
      }

      _ttSource = null;
      return createScraperResult(true, {
        title,
        author,
        thumbnail,
        downloads,
        sourceUrl: url,
      });
    }

    throw new Error("Invalid source selected.");
  } catch (err) {
    _ttSource = null;
    return createScraperResult(false, err.message, currentStatus);
  }
}

export async function scrapeSnapTik(url) {
  setTikTokSource("snaptik");
  return scrapeTikTok(url);
}

export async function scrapeTikTokIO(url) {
  setTikTokSource("tiktokio");
  return scrapeTikTok(url);
}

export async function scrapeSSSTik(url) {
  setTikTokSource("ssstik");
  return scrapeTikTok(url);
}

export async function scrapeTikDownloader(url) {
  setTikTokSource("tikdownloader");
  return scrapeTikTok(url);
}
