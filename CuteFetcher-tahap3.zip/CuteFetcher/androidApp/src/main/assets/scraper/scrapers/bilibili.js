import { CHROME_UA } from "../utils/index.js";
import { getCleanUrl } from "../utils/urlUtils.js";
import { scraperFetch, createScraperResult } from "./httpHelper.js";

async function sha256(message) {
  const msgUint8 = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest("SHA-256", msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function scrapeBilibili(url) {
  try {
    let cleanUrl = getCleanUrl(url);

    // Resolve redirection if it's a short URL (b23.tv or bili.im)
    if (cleanUrl.includes("b23.tv") || cleanUrl.includes("bili.im")) {
      try {
        const redirectRes = await scraperFetch(
          {
            url: cleanUrl,
            rawResponse: true,
          },
          "Bilibili Redirect",
        );
        if (redirectRes.url && redirectRes.url !== cleanUrl) {
          cleanUrl = redirectRes.url;
        } else if (redirectRes.data && typeof redirectRes.data === "string") {
          const hrefMatch = redirectRes.data.match(/href="([^"]+)"/i);
          if (hrefMatch) {
            cleanUrl = hrefMatch[1].replace(/&amp;/g, "&");
          }
        }
      } catch (e) {
        console.error("Bilibili redirect resolve failed:", e);
      }
    }

    if (cleanUrl.includes("bilibili.tv")) {
      try {
        const u = new URL(cleanUrl);
        cleanUrl = u.origin + u.pathname;
      } catch (e) {}

      try {
        const urlObj = new URL(cleanUrl);
        const parts = urlObj.pathname.split("/").filter(Boolean);

        let apiInfo = null;
        let title = "Bilibili.tv Video";
        let thumbnail = null;

        const idxVideo = parts.indexOf("video");
        if (idxVideo !== -1) {
          const aid = parts[idxVideo + 1];
          if (aid && /^\d+$/.test(aid)) {
            apiInfo = { tipo: "video", id: aid };
          }
        }

        const idxPlay = parts.indexOf("play");
        if (idxPlay !== -1) {
          const numericParts = parts
            .slice(idxPlay + 1)
            .filter((p) => /^\d+$/.test(p));
          if (numericParts.length > 1) {
            apiInfo = { tipo: "anime", id: numericParts[1] };
          } else if (numericParts.length === 1) {
            apiInfo = { tipo: "anime", id: null, seasonId: numericParts[0] };
          }
        }

        if (!apiInfo) {
          throw new Error("Could not parse Bilibili.tv video or episode ID.");
        }

        let html = "";
        try {
          html = await scraperFetch(
            {
              url: cleanUrl,
              parseJson: false,
            },
            "Bilibili Metadata",
          );
          html = typeof html === "string" ? html : "";
          const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
          if (titleMatch) title = titleMatch[1].trim();

          const imageMatch =
            html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i) ||
            html.match(/<meta\s+name="twitter:image"\s+content="([^"]+)"/i);
          if (imageMatch) thumbnail = imageMatch[1];
        } catch (err) {
          console.error("Failed to fetch Bilibili.tv page metadata:", err);
        }

        if (apiInfo.tipo === "anime" && !apiInfo.id && apiInfo.seasonId) {
          try {
            const epData = await scraperFetch(
              {
                url: `https://api.bilibili.tv/intl/gateway/web/v2/ogv/play/episodes?season_id=${apiInfo.seasonId}&platform=web&s_locale=en_US`,
              },
              "Bilibili Episodes",
            );
            if (epData && epData.data && epData.data.sections) {
              for (const sec of epData.data.sections) {
                if (sec.episodes && sec.episodes.length > 0) {
                  const firstEp = sec.episodes[0];
                  apiInfo.id =
                    firstEp.episode_id || firstEp.ep_id || firstEp.id;
                  if (firstEp.title_display && title === "Bilibili.tv Video") {
                    title = firstEp.title_display;
                  }
                  if (firstEp.cover && !thumbnail) {
                    thumbnail = firstEp.cover;
                  }
                  break;
                }
              }
            }
          } catch (e) {
            console.error("Failed to resolve season episodes:", e);
          }
          if (!apiInfo.id && html) {
            const epMatch =
              html.match(/"episode_id"\s*:\s*"(\d+)"/) ||
              html.match(/"episode_id"\s*:\s*(\d+)/) ||
              html.match(/"ep_id"\s*:\s*(\d+)/);
            if (epMatch) apiInfo.id = epMatch[1];
          }
        }

        const downloads = [];

        if (apiInfo.tipo === "anime" && (apiInfo.id || apiInfo.seasonId)) {
          try {
            const param = apiInfo.id
              ? `ep_id=${apiInfo.id}`
              : `season_id=${apiInfo.seasonId}`;
            const v2Data = await scraperFetch(
              {
                url: `https://api.bilibili.tv/intl/gateway/v2/ogv/playurl?${param}&platform=web&s_locale=en_US`,
              },
              "Bilibili OGV v2",
            );
            if (v2Data && v2Data.data && v2Data.data.video_info) {
              const streamList = v2Data.data.video_info.stream_list || [];
              streamList.forEach((s) => {
                const playUrl =
                  s.url ||
                  s.url_list?.[0]?.url ||
                  s.dash_video?.base_url ||
                  s.dash_video?.backup_url?.[0];
                if (playUrl) {
                  let secureUrl = playUrl;
                  if (secureUrl.startsWith("http://")) {
                    secureUrl = secureUrl.replace("http://", "https://");
                  }
                  const quality =
                    s.stream_info?.display_desc ||
                    s.stream_info?.description ||
                    s.desc_words ||
                    (s.quality ? `${s.quality}p` : "HD");
                  downloads.push({
                    url: secureUrl,
                    type: "VIDEO",
                    quality,
                    headers: {
                      Referer: "https://www.bilibili.tv/",
                    },
                  });
                }
              });

              const dash = v2Data.data.video_info.dash;
              if (dash) {
                if (dash.video && downloads.length === 0) {
                  dash.video.forEach((v) => {
                    let vUrl = v.base_url || v.backup_url?.[0];
                    if (vUrl) {
                      if (vUrl.startsWith("http://")) {
                        vUrl = vUrl.replace("http://", "https://");
                      }
                      downloads.push({
                        url: vUrl,
                        type: "VIDEO",
                        quality: `${v.id || 360}p`,
                        headers: {
                          Referer: "https://www.bilibili.tv/",
                        },
                      });
                    }
                  });
                }
                if (dash.audio) {
                  dash.audio.forEach((a) => {
                    let aUrl = a.base_url || a.backup_url?.[0];
                    if (aUrl) {
                      if (aUrl.startsWith("http://")) {
                        aUrl = aUrl.replace("http://", "https://");
                      }
                      downloads.push({
                        url: aUrl,
                        type: "AUDIO",
                        quality: "MP3",
                        headers: {
                          Referer: "https://www.bilibili.tv/",
                        },
                      });
                    }
                  });
                }
              }
            }
          } catch (e) {
            console.error("OGV v2 API failed:", e);
          }
        }

        if (downloads.length === 0 && apiInfo.id) {
          try {
            const playData = await scraperFetch(
              {
                url: `https://api.bilibili.tv/intl/gateway/web/v2/playurl?aid=${apiInfo.id}&platform=web&s_locale=en_US`,
              },
              "Bilibili PlayURL",
            );
            if (playData && playData.data && playData.data.playurl) {
              const videoList =
                playData.data.playurl.video || playData.data.playurl.durl || [];
              videoList.forEach((v) => {
                let vUrl = v.url || v.base_url;
                if (vUrl) {
                  if (vUrl.startsWith("http://")) {
                    vUrl = vUrl.replace("http://", "https://");
                  }
                  downloads.push({
                    url: vUrl,
                    type: "VIDEO",
                    quality: v.quality ? `${v.quality}p` : "HD",
                    headers: {
                      Referer: "https://www.bilibili.tv/",
                    },
                  });
                }
              });
            }
          } catch (e) {
            console.error("Fallback v2 PlayURL failed:", e);
          }
        }

        if (downloads.length > 0) {
          return createScraperResult(true, {
            title,
            thumbnail,
            downloads,
            sourceUrl: url,
          });
        }
      } catch (e) {
        console.error("Bilibili.tv parse error:", e);
      }
    }

    // Bilibili.com (BV / AV videos) Direct Engine
    const bvMatch = cleanUrl.match(/(BV[a-zA-Z0-9]{10})/i);
    const bvid = bvMatch ? bvMatch[1] : null;

    if (bvid) {
      try {
        const pageListRes = await scraperFetch(
          {
            url: `https://api.bilibili.com/x/player/pagelist?bvid=${bvid}`,
            headers: {
              "User-Agent": CHROME_UA,
              "Referer": `https://www.bilibili.com/video/${bvid}`,
            },
          },
          "Bilibili PageList",
        );

        let title = "Bilibili Video";
        let thumbnail = null;

        try {
          const pageRes = await scraperFetch(
            {
              url: `https://www.bilibili.com/video/${bvid}`,
              parseJson: false,
              headers: { "User-Agent": CHROME_UA },
            },
            "Bilibili Page Info",
          );
          if (typeof pageRes === "string") {
            const ogTitle = pageRes.match(/<meta\s+property=["']og:title["']\s+content=["']([^"']+)["']/i);
            const ogImg = pageRes.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']/i);
            if (ogTitle) title = ogTitle[1].replace(/_哔哩哔哩_bilibili.*$/i, "").trim();
            if (ogImg) thumbnail = ogImg[1];
          }
        } catch (_) {}

        if (pageListRes && pageListRes.code === 0 && Array.isArray(pageListRes.data) && pageListRes.data.length > 0) {
          const downloads = [];

          for (let i = 0; i < pageListRes.data.length; i++) {
            const p = pageListRes.data[i];
            const cid = p.cid;
            const partName = p.part || `Part ${i + 1}`;

            try {
              const playRes = await scraperFetch(
                {
                  url: `https://api.bilibili.com/x/player/playurl?bvid=${bvid}&cid=${cid}&qn=64&fnval=0`,
                  headers: {
                    "User-Agent": CHROME_UA,
                    "Referer": `https://www.bilibili.com/video/${bvid}`,
                  },
                },
                "Bilibili PlayURL",
              );

              if (playRes && playRes.code === 0 && playRes.data && Array.isArray(playRes.data.durl)) {
                playRes.data.durl.forEach((d) => {
                  if (d.url) {
                    downloads.push({
                      url: d.url,
                      type: "VIDEO",
                      quality: pageListRes.data.length > 1 ? `${partName} (720p HD)` : "720p HD",
                      headers: {
                        Referer: "https://www.bilibili.com/",
                        "User-Agent": CHROME_UA,
                      },
                    });
                  }
                });
              }
            } catch (err) {
              console.warn("Failed to fetch Bilibili playurl for cid:", cid, err);
            }
          }

          if (downloads.length > 0) {
            return createScraperResult(true, {
              title,
              thumbnail,
              author: "Bilibili Creator",
              downloads,
              sourceUrl: url,
            });
          }
        }
      } catch (err) {
        console.warn("Bilibili official API fetch failed:", err);
      }
    }

    throw new Error("Failed to process Bilibili URL. Media may be private or region-locked.");
  } catch (e) {
    return createScraperResult(false, e.message);
  }
}
