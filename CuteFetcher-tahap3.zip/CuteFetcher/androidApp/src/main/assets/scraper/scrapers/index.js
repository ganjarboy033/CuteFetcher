import { scraperFetch, createScraperResult, getRequestTimeout, parseJsonResponse } from "./httpHelper.js";
import { scrapeTikTok, setTikTokSource, _ttSource } from "./tiktok.js";
import { scrapeYouTube, setYouTubeSource, _ytSource } from "./youtube.js";
import { scrapeInstagram, setInstagramSource, _igSource } from "./instagram.js";
import { scrapeTwitter, setTwitterSource, _twSource } from "./twitter.js";
import { scrapeSpotify, setSpotifySource, _spSource } from "./spotify.js";
import { scrapeBilibili } from "./bilibili.js";
import { scrapePixiv } from "./pixiv.js";
import { scrapeRedNote } from "./rednote.js";
import { scrapeDouyin } from "./douyin.js";
import { scrapeThreads } from "./threads.js";
import { scrapePinterest } from "./pinterest.js";
import { scrapeAppleMusic } from "./applemusic.js";
import { scrapeFacebook } from "./facebook.js";
import { scrapeBandcamp } from "./bandcamp.js";
import { scrapeShopee } from "./shopee.js";
import { scrapeSoundCloud, setSoundCloudSource, _scSource } from "./soundcloud.js";

// Re-export all functions & helpers directly
export * from "./httpHelper.js";
export * from "./tiktok.js";
export * from "./youtube.js";
export * from "./instagram.js";
export * from "./twitter.js";
export * from "./spotify.js";
export * from "./bilibili.js";
export * from "./pixiv.js";
export * from "./rednote.js";
export * from "./douyin.js";
export * from "./threads.js";
export * from "./pinterest.js";
export * from "./applemusic.js";
export * from "./facebook.js";
export * from "./bandcamp.js";
export * from "./shopee.js";
export * from "./soundcloud.js";

// Platform namespace objects (for window.nimiyoEngine[platform][method])
export const youtube = {
  auto: (url) => { setYouTubeSource("auto"); return scrapeYouTube(url); },
  gg: (url) => { setYouTubeSource("gg"); return scrapeYouTube(url); },
  mobi: (url) => { setYouTubeSource("mobi"); return scrapeYouTube(url); },
  ytmp3: (url) => { setYouTubeSource("auto"); return scrapeYouTube(url); },
  direct: (url) => { setYouTubeSource("auto"); return scrapeYouTube(url); },
  default: (url) => { setYouTubeSource("auto"); return scrapeYouTube(url); }
};

export const tiktok = {
  snaptik: (url) => { setTikTokSource("snaptik"); return scrapeTikTok(url); },
  tiktokio: (url) => { setTikTokSource("tiktokio"); return scrapeTikTok(url); },
  ssstik: (url) => { setTikTokSource("ssstik"); return scrapeTikTok(url); },
  tikdownloader: (url) => { setTikTokSource("tikdownloader"); return scrapeTikTok(url); },
  direct: (url) => { setTikTokSource("tiktokio"); return scrapeTikTok(url); },
  default: scrapeTikTok
};

export const instagram = {
  snapsave: (url) => { setInstagramSource("snapsave"); return scrapeInstagram(url); },
  indown: (url) => { setInstagramSource("indown"); return scrapeInstagram(url); },
  direct: (url) => { setInstagramSource("direct"); return scrapeInstagram(url); },
  default: scrapeInstagram
};

export const twitter = {
  direct: (url) => { setTwitterSource("direct"); return scrapeTwitter(url); },
  tweeload: (url) => { setTwitterSource("tweeload"); return scrapeTwitter(url); },
  tvd: (url) => { setTwitterSource("tvd"); return scrapeTwitter(url); },
  default: scrapeTwitter
};

export const spotify = {
  soundloaders: (url) => { setSpotifySource("soundloaders"); return scrapeSpotify(url); },
  spotmate: (url) => { setSpotifySource("soundloaders"); return scrapeSpotify(url); },
  spotimate: (url) => { setSpotifySource("soundloaders"); return scrapeSpotify(url); },
  spotidown: (url) => { setSpotifySource("spotidown"); return scrapeSpotify(url); },
  spotisaver: (url) => { setSpotifySource("spotisaver"); return scrapeSpotify(url); },
  direct: (url) => { setSpotifySource("soundloaders"); return scrapeSpotify(url); },
  default: scrapeSpotify
};

export const soundcloud = {
  forhub: (url) => { setSoundCloudSource("forhub"); return scrapeSoundCloud(url); },
  klickaud: (url) => { setSoundCloudSource("klickaud"); return scrapeSoundCloud(url); },
  direct: (url) => { setSoundCloudSource("direct"); return scrapeSoundCloud(url); },
  default: (url) => { setSoundCloudSource("forhub"); return scrapeSoundCloud(url); }
};

export const facebook = {
  direct: scrapeFacebook,
  snapsave: scrapeFacebook,
  default: scrapeFacebook
};

export const pinterest = {
  direct: scrapePinterest,
  pindown: scrapePinterest,
  default: scrapePinterest
};

export const threads = {
  direct: scrapeThreads,
  threadster: scrapeThreads,
  default: scrapeThreads
};

export const bilibili = {
  direct: scrapeBilibili,
  default: scrapeBilibili
};

export const douyin = {
  direct: scrapeDouyin,
  default: scrapeDouyin
};

export const bandcamp = {
  direct: scrapeBandcamp,
  bandcampdownloader: scrapeBandcamp,
  default: scrapeBandcamp
};

export const pixiv = {
  direct: scrapePixiv,
  default: scrapePixiv
};

export const rednote = {
  direct: scrapeRedNote,
  default: scrapeRedNote
};

export const applemusic = {
  direct: scrapeAppleMusic,
  aplmate: scrapeAppleMusic,
  default: scrapeAppleMusic
};

export const shopee = {
  direct: scrapeShopee,
  svxtract: scrapeShopee,
  shopeenowatermark: scrapeShopee,
  default: scrapeShopee
};

// Export to window for global access in app.js and share.js
if (typeof window !== "undefined") {
  window.nimiyoEngine = {
    scraperFetch,
    createScraperResult,
    youtube,
    tiktok,
    instagram,
    twitter,
    spotify,
    soundcloud,
    facebook,
    pinterest,
    threads,
    bilibili,
    douyin,
    bandcamp,
    pixiv,
    rednote,
    applemusic,
    shopee,
    scrapeTikTok,
    scrapeYouTube,
    scrapeInstagram,
    scrapeTwitter,
    scrapeSpotify,
    scrapeSoundCloud,
    scrapeBilibili,
    scrapePixiv,
    scrapeRedNote,
    scrapeDouyin,
    scrapeThreads,
    scrapePinterest,
    scrapeAppleMusic,
    scrapeFacebook,
    scrapeBandcamp,
    scrapeShopee
  };
}
