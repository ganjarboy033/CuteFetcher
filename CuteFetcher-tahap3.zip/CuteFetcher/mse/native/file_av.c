#include "file_av.h"
#include "audio_fx.h"
#include "mse_ffmpeg.h"
#include "vpipe.h"
#include "vpresent.h"

#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/channel_layout.h>
#include <libavutil/frame.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
#include <libavutil/pixfmt.h>
#include <libavutil/rational.h>
#include <libavutil/samplefmt.h>
#include <libavutil/time.h>
#include <libswresample/swresample.h>

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#if defined(__APPLE__)
#include <AudioToolbox/AudioToolbox.h>
#define FILE_AV_AQ 1
#elif defined(__linux__) && !defined(__ANDROID__)
#include "aq_pulse.h"
#define FILE_AV_AQ 1
#elif defined(_WIN32)
#include "aq_winmm.h"
#define FILE_AV_AQ 1
#endif
#ifdef __APPLE__
#include <mach/mach_time.h>
#endif
#include "mse_ffmpeg.h"

#define OUT_RATE 48000
#define AQ_NBUFS 4
#define OUT_CH 2
#define V_EARLY 0.001
#define V_STALE 0.020
#define VOUT_N 4
#define MAX_DROP 2
#define IDLE_NS_MAX (16 * 1000 * 1000)
#ifdef _WIN32
/* waveOut underruns on ~11 ms buffers under UI load. */
#define AQ_BUF_FRAMES 2048
/* AQ_NBUFS of those (~170 ms) sit ahead of the speaker: count frames as they play out, not as queued. */
#define FILE_AV_PLAYOUT_CLOCK 1
#else
#define AQ_BUF_FRAMES 512
#endif


enum { ST_AUDIO = 0, ST_VIDEO = 1, ST_TEXT = 2 };

typedef struct {
    int kind;
    int index;
    int w, h;
    char lang[16];
    char codec[32];
} StreamInfo;

typedef struct {
    AVPacket **p;
    int n, cap, rd;
} Pq;

struct FileAv {
    pthread_mutex_t mu;
    pthread_cond_t cv;
    pthread_t th;
    int th_on;
#ifdef FILE_AV_AQ
    pthread_t ath;
    int ath_on;
    int a_busy;
#endif
    int stop;
    int dec_busy;
    int dec_epoch;
    int fmt_eof;
    int dec_drain;
    int opened;
    int playing;
    int ended;
    int want_video;
    int v_need_key; /* after rest: drop until a key at/after the clock */
    int v_open;     /* the video decoder is open */
    int v_dead;     /* 1: the video decoder gave up, not reported yet; 2: reported */
    int audio_index; /* -1 = first audio */
    double speed;
    AudioFx *fx;
    double hold;
    double origin_ns;
    double duration;
    double last_prog_ns;
    double last_vpts;
    int64_t idle_ns;
    int logged_drop;
    char err[256];

    AVFormatContext *fmt;
    AVCodecContext *adec;
    AVCodecContext *sdec;
    int a_st, v_st, s_st;
    int subtitle_index; /* -1 off; kept across close so reopen restores */
    SwrContext *swr;
    SwrContext *swr_speed;
    double swr_speed_in;
    uint8_t *pcm;
    size_t pcm_n;
    uint8_t *pcm2;
    size_t pcm2_n;
    /* mu; vpipe holds its own reference. */
    VPresenter *vp;
    /* Decoder calls run on dec_loop, or under mu while dec_loop is idle. */
    VPipe *vpipe;
    int vw, vh;
    Pq aq, vq;
    AVFrame *afr, *vfr;
    AVFrame *vout[VOUT_N];
    int vout_rd, vout_n;
    StreamInfo *streams;
    int nstreams;

    FileAvPcmFn on_pcm;
    FileAvProgressFn on_prog;
    FileAvEventFn on_event;
    FileAvCaptionFn on_caption;
    void *user;
    int cap_id, cap_n;
    struct {
        int id;
        double start, end;
        char text[1024];
    } cap_q[8];

#ifdef FILE_AV_AQ
    /* AudioQueue DAC. samples_played is the gold clock (same as leftover MSE). */
    AudioQueueRef dac;
    uint8_t *ring;
    int ring_cap, ring_r, ring_w, ring_n;
    int dac_started, dac_buf_bytes, flushing;
    int out_rate, out_ch;
    int64_t samples_played;
    double seek_base;
    double dac_tick_ns;
#endif
#ifdef FILE_AV_PLAYOUT_CLOCK
    /* Buffers queued at the device, in play order, with the frames of real audio each holds. */
    AudioQueueBufferRef dac_q[AQ_NBUFS];
    int dac_q_real[AQ_NBUFS];
    int dac_q_n;
#endif
};

static double now_ns(void)
{
#ifdef __APPLE__
    static mach_timebase_info_data_t tb;
    static int once;
    if (!once) {
        mach_timebase_info(&tb);
        once = 1;
    }
    return (double)mach_absolute_time() * (double)tb.numer / (double)tb.denom;
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1e9 + (double)ts.tv_nsec;
#endif
}

static void set_err(FileAv *p, const char *msg)
{
    snprintf(p->err, sizeof(p->err), "%s", msg ? msg : "");
}

static void pq_clear(Pq *q)
{
    int i;
    /* Popped slots (0..rd-1) were already av_packet_free'd. Freeing them
       again is the seek SIGSEGV in av_freep. */
    for (i = q->rd; i < q->n; i++)
        av_packet_free(&q->p[i]);
    free(q->p);
    q->p = NULL;
    q->n = q->cap = q->rd = 0;
}

static int pq_push(Pq *q, AVPacket *pkt)
{
    if (q->n >= q->cap) {
        int cap = q->cap ? q->cap * 2 : 16;
        AVPacket **n = realloc(q->p, (size_t)cap * sizeof(*n));
        if (!n)
            return -1;
        q->p = n;
        q->cap = cap;
    }
    q->p[q->n++] = pkt;
    return 0;
}

static uint8_t *grow_bytes(uint8_t **p, size_t *cap, size_t n)
{
    uint8_t *np;
    if (*p && *cap >= n)
        return *p;
    np = realloc(*p, n);
    if (!np)
        return NULL;
    *p = np;
    *cap = n;
    return np;
}

static AVPacket *pq_pop(Pq *q)
{
    AVPacket *pkt;
    if (q->rd >= q->n)
        return NULL;
    pkt = q->p[q->rd];
    q->p[q->rd] = NULL;
    q->rd++;
    if (q->rd == q->n)
        q->rd = q->n = 0;
    return pkt;
}

static void vout_clear(FileAv *p)
{
    while (p->vout_n > 0) {
        av_frame_unref(p->vout[p->vout_rd]);
        p->vout_rd = (p->vout_rd + 1) % VOUT_N;
        p->vout_n--;
    }
}

static AVFrame *vout_head(FileAv *p)
{
    return p->vout_n > 0 ? p->vout[p->vout_rd] : NULL;
}

static void vout_pop(FileAv *p)
{
    if (p->vout_n <= 0)
        return;
    av_frame_unref(p->vout[p->vout_rd]);
    p->vout_rd = (p->vout_rd + 1) % VOUT_N;
    p->vout_n--;
    pthread_cond_broadcast(&p->cv);
}

static int vout_push(FileAv *p, AVFrame *src)
{
    int i;
    if (p->vout_n >= VOUT_N || !src)
        return -1;
    i = (p->vout_rd + p->vout_n) % VOUT_N;
    if (!p->vout[i]) {
        p->vout[i] = av_frame_alloc();
        if (!p->vout[i])
            return -1;
    }
    av_frame_unref(p->vout[i]);
    if (av_frame_ref(p->vout[i], src) < 0)
        return -1;
    p->vout_n++;
    return 0;
}

/* Audio and subtitles. */
static AVCodecContext *open_codec(AVStream *st)
{
    const AVCodec *c = avcodec_find_decoder(st->codecpar->codec_id);
    AVCodecContext *ctx;
    if (!c)
        return NULL;
    ctx = avcodec_alloc_context3(c);
    if (!ctx)
        return NULL;
    if (avcodec_parameters_to_context(ctx, st->codecpar) < 0) {
        avcodec_free_context(&ctx);
        return NULL;
    }
    ctx->pkt_timebase = st->time_base;
    if (avcodec_open2(ctx, c, NULL) < 0) {
        avcodec_free_context(&ctx);
        return NULL;
    }
    return ctx;
}

static double frame_pts(AVStream *st, AVFrame *fr, double fallback)
{
    int64_t t = fr->best_effort_timestamp;
    if (t == AV_NOPTS_VALUE)
        t = fr->pts;
    if (t == AV_NOPTS_VALUE || !st)
        return fallback;
    return t * av_q2d(st->time_base);
}

static double media_time_locked(FileAv *p)
{
    double t = p->hold < 0 ? 0 : p->hold;
#ifdef FILE_AV_AQ
    /* Gold: AudioQueue samples_played, interpolated between callbacks.
       Counting only at 2048-frame (~42ms) callbacks jumped the clock past
       V_STALE and dropped every other 60fps picture. */
    if (p->playing && p->dac_started && p->out_rate > 0) {
        t = p->seek_base + (double)p->samples_played / (double)p->out_rate * p->speed;
        if (p->dac_tick_ns > 0) {
            double extra = (now_ns() - p->dac_tick_ns) / 1e9 * p->speed;
            double one = 0.012;
#ifdef FILE_AV_PLAYOUT_CLOCK
            /* Only through the real audio of the buffer playing now: padding and primed silence hold. */
            one = (p->dac_q_n > 0 ? p->dac_q_real[0] : 0) / (double)p->out_rate * p->speed;
#else
            if (p->dac_buf_bytes > 0) {
                int fb = p->out_ch > 0 ? p->out_ch * 2 : OUT_CH * 2;
                one = (double)p->dac_buf_bytes / (double)(p->out_rate * fb) * p->speed;
            }
#endif
            if (extra > one)
                extra = one;
            if (extra > 0)
                t += extra;
        }
        if (t < 0)
            t = 0;
        if (p->duration > 0 && t > p->duration)
            t = p->duration;
        return t;
    }
#endif
    if (p->playing && p->origin_ns > 0)
        t += (now_ns() - p->origin_ns) / 1e9 * p->speed;
    if (t < 0)
        t = 0;
    if (p->duration > 0 && t > p->duration)
        t = p->duration;
    return t;
}

/* dec_loop idle. Does not wait on it. */
static void drop_video_state_locked(FileAv *p)
{
    vpipe_close(p->vpipe);
    p->v_open = 0;
    pq_clear(&p->vq);
    vout_clear(p);
    av_frame_unref(p->vfr);
    vpipe_flush_picture(p->vpipe);
    p->dec_drain = 0;
    p->last_vpts = -1;
    p->v_need_key = 1;
}

/* Close the video decoder. Audio clock / demux position stay. */
static void rest_video_locked(FileAv *p)
{
    p->dec_epoch++;
    pthread_cond_broadcast(&p->cv);
    while (p->dec_busy)
        pthread_cond_wait(&p->cv, &p->mu);
    drop_video_state_locked(p);
}

static int start_video_locked(FileAv *p)
{
    AVStream *st;
    if (p->v_st < 0 || p->v_open || !p->fmt)
        return 0;
    st = p->fmt->streams[p->v_st];
    if (vpipe_open(p->vpipe, st->codecpar, st->time_base) < 0) {
        vpipe_failure(p->vpipe, p->err, (int)sizeof(p->err));
        return -1;
    }
    p->v_open = 1;
    p->v_dead = 0;
    p->vw = st->codecpar->width;
    p->vh = st->codecpar->height;
    p->v_need_key = 1;
    p->dec_drain = 0;
    pthread_cond_broadcast(&p->cv);
    return 0;
}

static void free_codecs(FileAv *p)
{
    avcodec_free_context(&p->adec);
    avcodec_free_context(&p->sdec);
    p->s_st = -1;
    p->cap_n = 0;
    drop_video_state_locked(p);
    swr_free(&p->swr);
    swr_free(&p->swr_speed);
    p->swr_speed_in = 0;
    pq_clear(&p->aq);
}

static double pkt_pts_sec(const FileAv *p, const AVPacket *pkt)
{
    AVStream *st;
    int64_t t;
    if (!p->fmt || p->v_st < 0 || !pkt)
        return -1;
    st = p->fmt->streams[p->v_st];
    t = pkt->pts != AV_NOPTS_VALUE ? pkt->pts : pkt->dts;
    if (t == AV_NOPTS_VALUE || !st)
        return -1;
    return t * av_q2d(st->time_base);
}

static double stream_pkt_pts(const FileAv *p, const AVPacket *pkt)
{
    AVStream *st;
    int64_t t;
    if (!p->fmt || !pkt || pkt->stream_index < 0 ||
        (unsigned)pkt->stream_index >= p->fmt->nb_streams)
        return -1;
    st = p->fmt->streams[pkt->stream_index];
    t = pkt->pts != AV_NOPTS_VALUE ? pkt->pts : pkt->dts;
    if (t == AV_NOPTS_VALUE)
        return -1;
    return t * av_q2d(st->time_base);
}

static void strip_ass_codes(const char *in, char *out, int n)
{
    int o = 0, skip = 0;
    for (; in && *in && o < n - 1; in++) {
        if (*in == '{') {
            skip = 1;
            continue;
        }
        if (skip) {
            if (*in == '}')
                skip = 0;
            continue;
        }
        if (in[0] == '\\' && (in[1] == 'N' || in[1] == 'n')) {
            out[o++] = '\n';
            in++;
            continue;
        }
        out[o++] = *in;
    }
    out[o] = 0;
}

static void ass_body(const char *ass, char *out, int n)
{
    const char *p = ass;
    int commas = 0;
    out[0] = 0;
    if (!p)
        return;
    if (!strncmp(p, "Dialogue:", 9)) {
        p += 9;
        while (*p && commas < 9) {
            if (*p++ == ',')
                commas++;
        }
    }
    strip_ass_codes(p, out, n);
}

static void cap_push(FileAv *p, double start, double end, const char *text)
{
    int i;
    if (!text || !text[0])
        return;
    if (end <= start)
        end = start + 5.0;
    if (p->cap_n >= 8) {
        memmove(&p->cap_q[0], &p->cap_q[1], sizeof(p->cap_q[0]) * 7);
        p->cap_n = 7;
    }
    i = p->cap_n++;
    p->cap_q[i].id = ++p->cap_id;
    p->cap_q[i].start = start;
    p->cap_q[i].end = end;
    snprintf(p->cap_q[i].text, sizeof(p->cap_q[i].text), "%s", text);
}

static int copy_text(const uint8_t *data, int len, char *out, int n)
{
    if (!data || len <= 0 || n <= 1)
        return -1;
    if (len >= n)
        len = n - 1;
    memcpy(out, data, (size_t)len);
    out[len] = 0;
    return 0;
}

/* Bundled libav often has no subtitle decoder. 3GPP timed text is length+UTF-8. */
static int parse_mov_text(const uint8_t *data, int size, char *out, int n)
{
    int len;
    if (size < 2)
        return -1;
    len = (data[0] << 8) | data[1];
    if (len <= 0)
        return -1;
    if (len > size - 2)
        len = size - 2;
    return copy_text(data + 2, len, out, n);
}

static void decode_sub_pkt(FileAv *p, AVPacket *pkt)
{
    AVStream *st;
    enum AVCodecID id;
    double pts, dur, start, end;
    char text[1024];

    if (!p->fmt || p->s_st < 0 || !pkt || !pkt->data)
        return;
    st = p->fmt->streams[p->s_st];
    id = st->codecpar->codec_id;
    pts = stream_pkt_pts(p, pkt);
    if (pts < 0)
        pts = 0;
    dur = 0;
    if (pkt->duration > 0)
        dur = pkt->duration * av_q2d(st->time_base);
    start = pts;
    end = dur > 0 ? pts + dur : pts;
    text[0] = 0;
    if (p->sdec) {
        AVSubtitle sub;
        int got = 0;
        unsigned i;
        size_t n = 0;
        memset(&sub, 0, sizeof(sub));
        if (avcodec_decode_subtitle2(p->sdec, &sub, &got, pkt) >= 0 && got) {
            if (sub.pts != AV_NOPTS_VALUE)
                pts = sub.pts / (double)AV_TIME_BASE;
            start = pts + sub.start_display_time / 1000.0;
            end = pts + sub.end_display_time / 1000.0;
            for (i = 0; i < sub.num_rects; i++) {
                AVSubtitleRect *r = sub.rects[i];
                char piece[1024];
                piece[0] = 0;
                if (!r)
                    continue;
                if (r->type == SUBTITLE_ASS && r->ass)
                    ass_body(r->ass, piece, (int)sizeof(piece));
                else if (r->text && r->text[0])
                    snprintf(piece, sizeof(piece), "%s", r->text);
                else if (r->ass && r->ass[0])
                    ass_body(r->ass, piece, (int)sizeof(piece));
                if (!piece[0])
                    continue;
                if (n && n < sizeof(text) - 2) {
                    text[n++] = '\n';
                    text[n] = 0;
                }
                snprintf(text + n, sizeof(text) - n, "%s", piece);
                n = strlen(text);
            }
            avsubtitle_free(&sub);
        }
    }
    if (!text[0]) {
        if (id == AV_CODEC_ID_MOV_TEXT)
            parse_mov_text(pkt->data, pkt->size, text, (int)sizeof(text));
        else if (id == AV_CODEC_ID_SUBRIP || id == AV_CODEC_ID_SRT ||
                 id == AV_CODEC_ID_WEBVTT || id == AV_CODEC_ID_TEXT)
            copy_text(pkt->data, pkt->size, text, (int)sizeof(text));
        else if (id == AV_CODEC_ID_ASS || id == AV_CODEC_ID_SSA)
            ass_body((const char *)pkt->data, text, (int)sizeof(text));
    }
    cap_push(p, start, end, text);
}

static void open_sdec_locked(FileAv *p)
{
    AVStream *st;
    avcodec_free_context(&p->sdec);
    p->s_st = -1;
    p->cap_n = 0;
    if (p->subtitle_index < 0 || !p->fmt)
        return;
    if ((unsigned)p->subtitle_index >= p->fmt->nb_streams)
        return;
    st = p->fmt->streams[p->subtitle_index];
    if (!st || st->codecpar->codec_type != AVMEDIA_TYPE_SUBTITLE)
        return;
    p->sdec = open_codec(st);
    /* Decoder is optional: bundled libav often ships without mov_text. */
    p->s_st = p->subtitle_index;
}

static void emit_captions(FileAv *p)
{
    struct {
        int id;
        double start, end;
        char text[1024];
    } tmp[8];
    int n, i;
    FileAvCaptionFn cap;
    void *user;
    if (p->cap_n <= 0 || !p->on_caption)
        return;
    n = p->cap_n;
    memcpy(tmp, p->cap_q, (size_t)n * sizeof(tmp[0]));
    p->cap_n = 0;
    cap = p->on_caption;
    user = p->user;
    pthread_mutex_unlock(&p->mu);
    for (i = 0; i < n; i++)
        cap(user, tmp[i].id, tmp[i].start, tmp[i].end, tmp[i].text);
    pthread_mutex_lock(&p->mu);
}

static void collect_streams(FileAv *p)
{
    unsigned i;
    free(p->streams);
    p->streams = NULL;
    p->nstreams = 0;
    if (!p->fmt)
        return;
    p->streams = calloc(p->fmt->nb_streams, sizeof(StreamInfo));
    if (!p->streams)
        return;
    for (i = 0; i < p->fmt->nb_streams; i++) {
        AVStream *st = p->fmt->streams[i];
        AVDictionaryEntry *lang;
        StreamInfo *s = &p->streams[p->nstreams];
        const char *name = avcodec_get_name(st->codecpar->codec_id);
        if (st->codecpar->codec_type == AVMEDIA_TYPE_AUDIO)
            s->kind = ST_AUDIO;
        else if (st->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            if (st->disposition & AV_DISPOSITION_ATTACHED_PIC)
                continue;
            s->kind = ST_VIDEO;
            s->w = st->codecpar->width;
            s->h = st->codecpar->height;
        } else if (st->codecpar->codec_type == AVMEDIA_TYPE_SUBTITLE)
            s->kind = ST_TEXT;
        else
            continue;
        s->index = (int)i;
        lang = av_dict_get(st->metadata, "language", NULL, 0);
        if (lang && lang->value)
            snprintf(s->lang, sizeof(s->lang), "%s", lang->value);
        if (name)
            snprintf(s->codec, sizeof(s->codec), "%s", name);
        p->nstreams++;
    }
}

static int pick_audio(FileAv *p)
{
    int i, first = -1;
    for (i = 0; i < p->nstreams; i++) {
        if (p->streams[i].kind != ST_AUDIO)
            continue;
        if (first < 0)
            first = p->streams[i].index;
        if (p->audio_index >= 0 && p->streams[i].index == p->audio_index)
            return p->streams[i].index;
    }
    return first;
}

static int pick_video(FileAv *p)
{
    int i, best = -1, best_area = -1;
    for (i = 0; i < p->nstreams; i++) {
        int area;
        if (p->streams[i].kind != ST_VIDEO)
            continue;
        area = p->streams[i].w * p->streams[i].h;
        if (area > best_area) {
            best_area = area;
            best = p->streams[i].index;
        }
    }
    return best;
}

static int need_video(const FileAv *p)
{
    return p->want_video && p->v_open;
}

static int setup_decoders(FileAv *p)
{
    p->a_st = pick_audio(p);
    p->v_st = pick_video(p);
    if (p->a_st >= 0) {
        p->adec = open_codec(p->fmt->streams[p->a_st]);
        if (!p->adec) {
            set_err(p, "audio decoder");
            return -1;
        }
    }
    if (p->v_st >= 0) {
        AVStream *st = p->fmt->streams[p->v_st];
        p->vw = st->codecpar->width;
        p->vh = st->codecpar->height;
        if (p->want_video && start_video_locked(p) != 0)
            return -1;
    }
    if (p->a_st < 0 && p->v_st < 0) {
        set_err(p, "no audio or video stream");
        return -1;
    }
    open_sdec_locked(p);
    return 0;
}

static int fill_packets(FileAv *p)
{
    int i;
    if (!p->want_video && p->a_st < 0)
        return 0; /* video-only rest: do not race the file to EOF */
    for (i = 0; i < 24; i++) {
        AVPacket *pkt;
        if (p->aq.n - p->aq.rd > 8 && (!p->want_video || p->v_st < 0 || p->vq.n - p->vq.rd > 8))
            return 0;
        pkt = av_packet_alloc();
        if (!pkt)
            return -1;
        if (av_read_frame(p->fmt, pkt) < 0) {
            av_packet_free(&pkt);
            return 1; /* eof */
        }
        if (pkt->stream_index == p->a_st) {
            if (pq_push(&p->aq, pkt) < 0)
                av_packet_free(&pkt);
        } else if (pkt->stream_index == p->v_st && p->want_video && p->v_open) {
            if (p->v_need_key) {
                double t = pkt_pts_sec(p, pkt);
                double clock = media_time_locked(p);
                if (!(pkt->flags & AV_PKT_FLAG_KEY) || (t >= 0 && t + 0.04 < clock)) {
                    av_packet_free(&pkt);
                    continue;
                }
                p->v_need_key = 0;
            }
            if (pq_push(&p->vq, pkt) < 0)
                av_packet_free(&pkt);
        } else if (pkt->stream_index == p->s_st) {
            decode_sub_pkt(p, pkt);
            av_packet_free(&pkt);
        } else {
            av_packet_free(&pkt);
        }
    }
    return 0;
}

static int ensure_swr(FileAv *p, AVFrame *fr)
{
    AVChannelLayout out_ch;
    int in_rate = fr->sample_rate > 0 ? fr->sample_rate : OUT_RATE;
    if (p->swr)
        return 0;
    memset(&out_ch, 0, sizeof(out_ch));
    av_channel_layout_default(&out_ch, OUT_CH);
    if (swr_alloc_set_opts2(&p->swr, &out_ch, AV_SAMPLE_FMT_S16, OUT_RATE,
                            &fr->ch_layout, (enum AVSampleFormat)fr->format,
                            in_rate, 0, NULL) < 0 ||
        swr_init(p->swr) < 0) {
        av_channel_layout_uninit(&out_ch);
        swr_free(&p->swr);
        return -1;
    }
    av_channel_layout_uninit(&out_ch);
    return 0;
}

static int ensure_speed_swr(FileAv *p, double speed)
{
    AVChannelLayout ch;
    double in_rate;
    if (speed < 0.05)
        speed = 0.05;
    if (speed > 4)
        speed = 4;
    in_rate = (double)OUT_RATE * speed;
    if (p->swr_speed && p->swr_speed_in == in_rate)
        return 0;
    swr_free(&p->swr_speed);
    p->swr_speed_in = 0;
    if (speed > 0.99 && speed < 1.01)
        return 0;
    memset(&ch, 0, sizeof(ch));
    av_channel_layout_default(&ch, OUT_CH);
    if (swr_alloc_set_opts2(&p->swr_speed, &ch, AV_SAMPLE_FMT_S16, OUT_RATE,
                            &ch, AV_SAMPLE_FMT_S16, (int)(in_rate + 0.5),
                            0, NULL) < 0 ||
        swr_init(p->swr_speed) < 0) {
        av_channel_layout_uninit(&ch);
        swr_free(&p->swr_speed);
        return -1;
    }
    av_channel_layout_uninit(&ch);
    p->swr_speed_in = in_rate;
    return 0;
}

#ifdef FILE_AV_AQ
static int ring_fb(const FileAv *p)
{
    return p->out_ch > 0 ? p->out_ch * 2 : OUT_CH * 2;
}

static int ring_ms(const FileAv *p)
{
    int rate = p->out_rate > 0 ? p->out_rate : OUT_RATE;
    int fb = ring_fb(p);
    if (!p->ring || rate <= 0 || fb <= 0)
        return 0;
    return (int)((int64_t)p->ring_n * 1000 / ((int64_t)rate * fb));
}

static void ring_write(FileAv *p, const uint8_t *src, int n)
{
    while (n > 0) {
        int space, chunk;
        if (p->ring_n >= p->ring_cap || p->flushing || !p->playing || !p->ring)
            return;
        space = p->ring_cap - p->ring_n;
        chunk = n < space ? n : space;
        if (p->ring_w + chunk > p->ring_cap) {
            int first = p->ring_cap - p->ring_w;
            memcpy(p->ring + p->ring_w, src, (size_t)first);
            memcpy(p->ring, src + first, (size_t)(chunk - first));
            p->ring_w = chunk - first;
        } else {
            memcpy(p->ring + p->ring_w, src, (size_t)chunk);
            p->ring_w += chunk;
        }
        p->ring_n += chunk;
        src += chunk;
        n -= chunk;
        pthread_cond_broadcast(&p->cv);
    }
}

static int ring_read(FileAv *p, uint8_t *dst, int n)
{
    int got = 0;
    int fb = ring_fb(p);
    if (fb > 1)
        n -= n % fb;
    while (got < n && p->ring_n > 0) {
        int chunk = n - got;
        if (chunk > p->ring_n)
            chunk = p->ring_n;
        if (p->ring_r + chunk > p->ring_cap) {
            int first = p->ring_cap - p->ring_r;
            memcpy(dst + got, p->ring + p->ring_r, (size_t)first);
            memcpy(dst + got + first, p->ring, (size_t)(chunk - first));
            p->ring_r = chunk - first;
        } else {
            memcpy(dst + got, p->ring + p->ring_r, (size_t)chunk);
            p->ring_r += chunk;
        }
        p->ring_n -= chunk;
        got += chunk;
    }
    return got;
}

/* mu held. Real frames still queued ahead of the speaker. */
static int dac_q_pending(const FileAv *p)
{
#ifdef FILE_AV_PLAYOUT_CLOCK
    int i, n = 0;
    for (i = 0; i < p->dac_q_n; i++)
        n += p->dac_q_real[i];
    return n;
#else
    (void)p;
    return 0;
#endif
}

#ifdef FILE_AV_PLAYOUT_CLOCK
/* mu held. buf has just played out: drop it from the queue, returning its real frames. */
static int dac_q_take(FileAv *p, AudioQueueBufferRef buf)
{
    int i, real;
    for (i = 0; i < p->dac_q_n; i++) {
        if (p->dac_q[i] != buf)
            continue;
        real = p->dac_q_real[i];
        p->dac_q_n--;
        memmove(&p->dac_q[i], &p->dac_q[i + 1], (size_t)(p->dac_q_n - i) * sizeof(p->dac_q[0]));
        memmove(&p->dac_q_real[i], &p->dac_q_real[i + 1], (size_t)(p->dac_q_n - i) * sizeof(p->dac_q_real[0]));
        return real;
    }
    return 0;
}

/* mu held. Each buffer is either queued or in the callback, so dac_q never holds more than AQ_NBUFS. */
static void dac_q_put(FileAv *p, AudioQueueBufferRef buf, int real)
{
    p->dac_q[p->dac_q_n] = buf;
    p->dac_q_real[p->dac_q_n] = real;
    p->dac_q_n++;
}
#endif

static void aq_callback(void *user, AudioQueueRef q, AudioQueueBufferRef buf)
{
    FileAv *p = user;
    int n = 0;
    int cap;
#ifdef FILE_AV_PLAYOUT_CLOCK
    int own;
#endif
    pthread_mutex_lock(&p->mu);
    cap = p->dac_buf_bytes > 0 ? p->dac_buf_bytes : (int)buf->mAudioDataBytesCapacity;
    if (cap > (int)buf->mAudioDataBytesCapacity)
        cap = (int)buf->mAudioDataBytesCapacity;
#ifdef FILE_AV_PLAYOUT_CLOCK
    /* stop_aq detaches the queue before disposing it; its last callbacks must not touch dac_q. */
    own = q == p->dac;
    if (own) {
        p->samples_played += dac_q_take(p, buf);
        p->dac_tick_ns = now_ns();
    }
#endif
    if (!p->stop && !p->flushing && p->playing && p->ring)
        n = ring_read(p, (uint8_t *)buf->mAudioData, cap);
    /* Colored at the device pull so EQ is instant and the spectrum matches what is heard. */
    if (n > 0 && p->fx)
        audio_fx_color(p->fx, (int16_t *)buf->mAudioData, n / ring_fb(p), ring_fb(p) / 2);
#ifdef FILE_AV_PLAYOUT_CLOCK
    if (own)
        dac_q_put(p, buf, n / ring_fb(p));
#else
    if (n > 0 && p->out_rate > 0) {
        p->samples_played += n / ring_fb(p);
        p->dac_tick_ns = now_ns();
    }
#endif
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
#ifdef FILE_AV_PLAYOUT_CLOCK
    /* Full length always: a short buffer plays out early and waveOut's refills fall behind (crackle). */
    if (n < cap)
        memset((uint8_t *)buf->mAudioData + n, 0, (size_t)(cap - n));
    n = cap;
#else
    if (n <= 0) {
        memset(buf->mAudioData, 0, (size_t)cap);
        n = cap;
    }
#endif
    buf->mAudioDataByteSize = (UInt32)n;
    AudioQueueEnqueueBuffer(q, buf, 0, NULL);
}

static int start_aq(FileAv *p)
{
    AudioStreamBasicDescription fmt;
    AudioQueueRef aq = NULL;
    uint8_t *ring = NULL;
    int i, buf_bytes, cap, rate = OUT_RATE, ch = OUT_CH;
    if (p->dac)
        return 0;
    memset(&fmt, 0, sizeof(fmt));
    fmt.mSampleRate = rate;
    fmt.mFormatID = kAudioFormatLinearPCM;
    fmt.mFormatFlags = kLinearPCMFormatFlagIsSignedInteger | kLinearPCMFormatFlagIsPacked |
                       kAudioFormatFlagsNativeEndian;
    fmt.mBytesPerPacket = (UInt32)(ch * 2);
    fmt.mFramesPerPacket = 1;
    fmt.mBytesPerFrame = (UInt32)(ch * 2);
    fmt.mChannelsPerFrame = (UInt32)ch;
    fmt.mBitsPerChannel = 16;
    cap = rate * ch * 2;
    buf_bytes = AQ_BUF_FRAMES * ch * 2;
    pthread_mutex_unlock(&p->mu);
    if (AudioQueueNewOutput(&fmt, aq_callback, p, NULL, kCFRunLoopCommonModes, 0, &aq) != 0) {
        pthread_mutex_lock(&p->mu);
        return -1;
    }
    ring = calloc(1, (size_t)cap);
    if (!ring) {
        AudioQueueDispose(aq, true);
        pthread_mutex_lock(&p->mu);
        return -1;
    }
    pthread_mutex_lock(&p->mu);
    if (p->dac || p->stop) {
        pthread_mutex_unlock(&p->mu);
        free(ring);
        AudioQueueDispose(aq, true);
        pthread_mutex_lock(&p->mu);
        return 0;
    }
    p->dac = aq;
    p->out_rate = rate;
    p->out_ch = ch;
    p->ring = ring;
    p->ring_cap = cap;
    p->ring_r = p->ring_w = p->ring_n = 0;
    p->dac_buf_bytes = buf_bytes;
    pthread_mutex_unlock(&p->mu);
    for (i = 0; i < AQ_NBUFS; i++) {
        AudioQueueBufferRef buf;
        if (AudioQueueAllocateBuffer(aq, (UInt32)buf_bytes, &buf) != 0)
            break;
        memset(buf->mAudioData, 0, buf->mAudioDataBytesCapacity);
        buf->mAudioDataByteSize = (UInt32)buf_bytes;
#ifdef FILE_AV_PLAYOUT_CLOCK
        pthread_mutex_lock(&p->mu);
        dac_q_put(p, buf, 0);
        pthread_mutex_unlock(&p->mu);
#endif
        AudioQueueEnqueueBuffer(aq, buf, 0, NULL);
    }
    pthread_mutex_lock(&p->mu);
    return 0;
}

static void aq_pause_flush(FileAv *p)
{
    AudioQueueRef aq;
    pthread_mutex_lock(&p->mu);
    p->flushing = 1;
    p->dac_started = 0;
    p->ring_r = p->ring_w = p->ring_n = 0;
    aq = p->dac;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
    if (aq) {
        AudioQueuePause(aq);
        AudioQueueFlush(aq);
    }
    pthread_mutex_lock(&p->mu);
    p->flushing = 0;
    pthread_mutex_unlock(&p->mu);
}

static void stop_aq(FileAv *p)
{
    AudioQueueRef aq;
    uint8_t *ring;
    pthread_mutex_lock(&p->mu);
    aq = p->dac;
    ring = p->ring;
    p->dac = NULL;
    p->ring = NULL;
    p->dac_started = 0;
    p->ring_cap = p->ring_r = p->ring_w = p->ring_n = 0;
#ifdef FILE_AV_PLAYOUT_CLOCK
    p->dac_q_n = 0;
#endif
    pthread_mutex_unlock(&p->mu);
    if (aq) {
        AudioQueueStop(aq, true);
        AudioQueueDispose(aq, true);
    }
    free(ring);
}

/* Decode one AAC frame to 48k s16. mu held on entry/exit. 1 = *out set. */
static int decode_pcm(FileAv *p, uint8_t **out, int *nbytes)
{
    AVPacket *pkt;
    int got, max_out;
    uint8_t *tmp = NULL, *sped = NULL;
    uint8_t *dsts[1];
    *out = NULL;
    *nbytes = 0;
    for (;;) {
        got = avcodec_receive_frame(p->adec, p->afr);
        if (got == AVERROR(EAGAIN)) {
            pkt = pq_pop(&p->aq);
            if (!pkt)
                return 0;
            if (avcodec_send_packet(p->adec, pkt) < 0) {
                av_packet_free(&pkt);
                return 0;
            }
            av_packet_free(&pkt);
            continue;
        }
        if (got < 0)
            return 0;
        if (ensure_swr(p, p->afr) < 0) {
            av_frame_unref(p->afr);
            return -1;
        }
        max_out = (int)swr_get_out_samples(p->swr, p->afr->nb_samples) + 256;
        if (max_out < 1)
            max_out = p->afr->nb_samples + 256;
        tmp = grow_bytes(&p->pcm, &p->pcm_n, (size_t)max_out * OUT_CH * 2);
        if (!tmp) {
            av_frame_unref(p->afr);
            return -1;
        }
        dsts[0] = tmp;
        got = swr_convert(p->swr, dsts, max_out,
                          (const uint8_t **)p->afr->extended_data, p->afr->nb_samples);
        av_frame_unref(p->afr);
        if (got <= 0)
            return 0;
        if (p->fx) {
            int cap = got * 4 + 1024;
            int16_t *stretched = (int16_t *)grow_bytes(&p->pcm2, &p->pcm2_n,
                                                      (size_t)cap * OUT_CH * sizeof(int16_t));
            int nout;
            audio_fx_set_rate(p->fx, OUT_RATE);
            audio_fx_set_speed(p->fx, (float)p->speed);
            if (stretched) {
                nout = audio_fx_stretch(p->fx, (int16_t *)tmp, got, stretched, cap, OUT_CH);
                tmp = (uint8_t *)stretched;
                got = nout;
            }
        } else if (p->swr_speed) {
            int mout = (int)swr_get_out_samples(p->swr_speed, got) + 256;
            uint8_t *ins[1] = {tmp};
            if (mout < 1)
                mout = got + 256;
            sped = grow_bytes(&p->pcm2, &p->pcm2_n, (size_t)mout * OUT_CH * 2);
            if (!sped)
                return -1;
            dsts[0] = sped;
            got = swr_convert(p->swr_speed, dsts, mout, (const uint8_t **)ins, got);
            tmp = sped;
            if (got <= 0)
                return 0;
        }
        *nbytes = got * OUT_CH * 2;
        *out = tmp;
        return 1;
    }
}

static void *a_loop(void *arg)
{
    FileAv *p = arg;
    for (;;) {
        uint8_t *pcm = NULL;
        int nbytes = 0, filled = 0;
        AudioQueueRef start_q = NULL;
        pthread_mutex_lock(&p->mu);
        p->a_busy = 0;
        pthread_cond_broadcast(&p->cv);
        while (!p->stop && !(p->opened && p->playing && p->adec))
            pthread_cond_wait(&p->cv, &p->mu);
        if (p->stop) {
            pthread_mutex_unlock(&p->mu);
            return NULL;
        }
        p->a_busy = 1;
        while (filled < 8 && ring_ms(p) < 400) {
            int r;
            if (!p->opened || !p->playing || !p->adec || p->flushing)
                break;
            r = decode_pcm(p, &pcm, &nbytes);
            if (r <= 0 || !pcm)
                break;
            if (!p->dac && start_aq(p) != 0) {
                pcm = NULL;
                if (p->origin_ns == 0)
                    p->origin_ns = now_ns();
                break;
            }
            if (!p->flushing)
                ring_write(p, pcm, nbytes);
            pcm = NULL;
            filled++;
            if (p->dac && !p->dac_started && ring_ms(p) >= 160) {
                p->dac_started = 1;
                p->samples_played = 0;
                p->dac_tick_ns = now_ns();
                start_q = p->dac;
            }
        }
        p->a_busy = 0;
        pthread_cond_broadcast(&p->cv);
        pthread_mutex_unlock(&p->mu);
        if (start_q)
            AudioQueueStart(start_q, NULL);
        if (filled == 0) {
            struct timespec sl = {0, 4 * 1000 * 1000};
            nanosleep(&sl, NULL);
        }
    }
}
#else
static int pump_audio(FileAv *p, double clock)
{
    AVPacket *pkt;
    int got, max_out;
    uint8_t *tmp = NULL, *sped = NULL;
    uint8_t *dsts[1];
    int nbytes;
    if (!p->adec)
        return 0;
    for (;;) {
        got = avcodec_receive_frame(p->adec, p->afr);
        if (got == AVERROR(EAGAIN)) {
            pkt = pq_pop(&p->aq);
            if (!pkt)
                return 0;
            if (avcodec_send_packet(p->adec, pkt) < 0) {
                av_packet_free(&pkt);
                return 0;
            }
            av_packet_free(&pkt);
            continue;
        }
        if (got < 0)
            return 0;
        if (ensure_swr(p, p->afr) < 0) {
            av_frame_unref(p->afr);
            return -1;
        }
        max_out = (int)swr_get_out_samples(p->swr, p->afr->nb_samples) + 256;
        if (max_out < 1)
            max_out = p->afr->nb_samples + 256;
        tmp = grow_bytes(&p->pcm, &p->pcm_n, (size_t)max_out * OUT_CH * 2);
        if (!tmp) {
            av_frame_unref(p->afr);
            return -1;
        }
        dsts[0] = tmp;
        got = swr_convert(p->swr, dsts, max_out,
                          (const uint8_t **)p->afr->extended_data, p->afr->nb_samples);
        av_frame_unref(p->afr);
        if (got <= 0)
            return 0;
        if (p->fx) {
            int cap = got * 4 + 1024;
            int16_t *stretched = (int16_t *)grow_bytes(&p->pcm2, &p->pcm2_n,
                                                      (size_t)cap * OUT_CH * sizeof(int16_t));
            int nout;
            audio_fx_set_rate(p->fx, OUT_RATE);
            audio_fx_set_speed(p->fx, (float)p->speed);
            if (stretched) {
                nout = audio_fx_stretch(p->fx, (int16_t *)tmp, got, stretched, cap, OUT_CH);
                tmp = (uint8_t *)stretched;
                got = nout;
            }
            if (got > 0)
                audio_fx_color(p->fx, (int16_t *)tmp, got, OUT_CH);
        } else if (ensure_speed_swr(p, p->speed) == 0 && p->swr_speed) {
            int mout = (int)swr_get_out_samples(p->swr_speed, got) + 256;
            uint8_t *ins[1] = {tmp};
            if (mout < 1)
                mout = got + 256;
            sped = grow_bytes(&p->pcm2, &p->pcm2_n, (size_t)mout * OUT_CH * 2);
            if (!sped)
                return -1;
            dsts[0] = sped;
            got = swr_convert(p->swr_speed, dsts, mout, (const uint8_t **)ins, got);
            tmp = sped;
            if (got <= 0)
                return 0;
        }
        nbytes = got * OUT_CH * 2;
        pthread_mutex_unlock(&p->mu);
        if (p->on_pcm)
            p->on_pcm(p->user, OUT_RATE, OUT_CH, (const int16_t *)tmp, nbytes);
        pthread_mutex_lock(&p->mu);
        (void)clock;
        if (!p->opened || !p->adec)
            return 0;
        return 0;
    }
}
#endif

static void set_idle(FileAv *p, double sec)
{
    int64_t ns;
    if (sec < 0)
        sec = 0;
    ns = (int64_t)(sec * 1e9);
    if (ns > IDLE_NS_MAX)
        ns = IDLE_NS_MAX;
    p->idle_ns = ns;
}

static int present_head(FileAv *p)
{
    AVFrame *fr = vout_head(p);
    AVStream *st = (p->fmt && p->v_st >= 0) ? p->fmt->streams[p->v_st] : NULL;
    int show = p->want_video, r;
    double pts;
    if (!fr)
        return 0;
    pts = frame_pts(st, fr, 0);
    p->idle_ns = 0;
    p->last_vpts = pts;
    pthread_mutex_unlock(&p->mu);
    r = show ? vpipe_present(p->vpipe, fr) : VP_DROPPED;
    pthread_mutex_lock(&p->mu);
    if (r == VP_OK) {
        /* The native size: the UI sizes the hole from it. */
        p->vw = fr->width;
        p->vh = fr->height;
    }
    if (p->playing && p->origin_ns == 0)
        p->origin_ns = now_ns();
    vout_pop(p);
    return 0;
}

/* 1x clock. Show the due head; drop at most two already-stale pictures. */
static int pump_video(FileAv *p, double clock)
{
    AVStream *st = (p->fmt && p->v_st >= 0) ? p->fmt->streams[p->v_st] : NULL;
    AVFrame *fr;
    double pts;
    int drops;
    if (!p->v_open || !p->want_video)
        return 0;
    if (!p->vp) {
        set_idle(p, 0.004);
        return 0;
    }
    clock = media_time_locked(p);
    drops = 0;
    while (drops < MAX_DROP && p->vout_n >= 2) {
        pts = frame_pts(st, vout_head(p), clock);
        if (pts + V_STALE >= clock)
            break;
        if (p->logged_drop < 8) {
            p->logged_drop++;
            mse_critf(MSE_LOG_INFO, "file-av drop-stale pts=%.3f clock=%.3f", pts, clock);
        }
        vout_pop(p);
        drops++;
    }
    fr = vout_head(p);
    if (!fr) {
        set_idle(p, 0.004);
        return 0;
    }
    pts = frame_pts(st, fr, clock);
    if (p->origin_ns == 0)
        return present_head(p);
    if (pts > clock + V_EARLY) {
        set_idle(p, pts - clock - V_EARLY);
        return 0;
    }
    return present_head(p);
}

/* mu held. VP_DEAD stops video (file_av_step reports it); VP_RESYNC restarts at a keyframe unless a
   seek already did. */
static void video_result_locked(FileAv *p, int r, int epoch)
{
    if (r == VP_DEAD) {
        vpipe_failure(p->vpipe, p->err, (int)sizeof(p->err));
        p->v_open = 0;
        p->v_dead = 1;
        pq_clear(&p->vq);
        vout_clear(p);
        return;
    }
    if (r != VP_RESYNC || epoch != p->dec_epoch)
        return;
    for (;;) {
        AVPacket *head = p->vq.rd < p->vq.n ? p->vq.p[p->vq.rd] : NULL;
        if (!head) {
            p->v_need_key = 1;
            return;
        }
        if (head->flags & AV_PKT_FLAG_KEY)
            return;
        head = pq_pop(&p->vq);
        av_packet_free(&head);
    }
}

static void *dec_loop(void *arg)
{
    FileAv *p = arg;
    for (;;) {
        AVPacket *pkt;
        int got, epoch;
        pthread_mutex_lock(&p->mu);
        for (;;) {
            if (p->stop) {
                pthread_mutex_unlock(&p->mu);
                return NULL;
            }
            if (p->opened && p->playing && p->v_open && p->want_video && p->vout_n < VOUT_N)
                break;
            pthread_cond_wait(&p->cv, &p->mu);
        }
        epoch = p->dec_epoch;
        p->dec_busy = 1;
        pthread_mutex_unlock(&p->mu);

        got = vpipe_receive(p->vpipe, p->vfr);
        pthread_mutex_lock(&p->mu);
        if (got == VP_DEAD)
            video_result_locked(p, got, epoch);
        if (p->stop || !p->opened || !p->v_open || epoch != p->dec_epoch) {
            av_frame_unref(p->vfr);
            p->dec_busy = 0;
            pthread_cond_broadcast(&p->cv);
            pthread_mutex_unlock(&p->mu);
            continue;
        }
        if (got == AVERROR(EAGAIN)) {
            pkt = pq_pop(&p->vq);
            if (!pkt && p->fmt_eof && !p->dec_drain) {
                p->dec_drain = 1;
                pthread_mutex_unlock(&p->mu);
                got = vpipe_send(p->vpipe, NULL, 0);
                pthread_mutex_lock(&p->mu);
                video_result_locked(p, got, epoch);
                p->dec_busy = 0;
                pthread_cond_broadcast(&p->cv);
                pthread_mutex_unlock(&p->mu);
                continue;
            }
            if (!pkt) {
                p->dec_busy = 0;
                pthread_cond_broadcast(&p->cv);
                pthread_cond_wait(&p->cv, &p->mu);
                pthread_mutex_unlock(&p->mu);
                continue;
            }
            pthread_mutex_unlock(&p->mu);
            got = vpipe_send(p->vpipe, pkt, (pkt->flags & AV_PKT_FLAG_KEY) != 0);
            av_packet_free(&pkt);
            pthread_mutex_lock(&p->mu);
            video_result_locked(p, got, epoch);
            p->dec_busy = 0;
            pthread_cond_broadcast(&p->cv);
            pthread_mutex_unlock(&p->mu);
            continue;
        }
        if (got < 0) {
            av_frame_unref(p->vfr);
            video_result_locked(p, got, epoch);
            p->dec_busy = 0;
            pthread_cond_broadcast(&p->cv);
            /* Drained: nothing more until a seek or close. */
            if (got == AVERROR_EOF)
                pthread_cond_wait(&p->cv, &p->mu);
            pthread_mutex_unlock(&p->mu);
            continue;
        }
        p->dec_busy = 0;
        pthread_cond_broadcast(&p->cv);
        while (!p->stop && p->opened && epoch == p->dec_epoch && p->vout_n >= VOUT_N)
            pthread_cond_wait(&p->cv, &p->mu);
        if (!p->stop && p->opened && epoch == p->dec_epoch)
            vout_push(p, p->vfr);
        av_frame_unref(p->vfr);
        pthread_cond_broadcast(&p->cv);
        pthread_mutex_unlock(&p->mu);
    }
}

int file_av_step(FileAv *p)
{
    double clock;
    int eof, a_empty, v_empty;
    int64_t idle_ns;
    if (!p)
        return 0;
    pthread_mutex_lock(&p->mu);
    if (!p->opened || !p->playing) {
        pthread_mutex_unlock(&p->mu);
        return 0;
    }
    if (p->v_dead == 1) {
        char err[sizeof(p->err)];
        FileAvEventFn ev = p->on_event;
        void *user = p->user;
        p->v_dead = 2;
        snprintf(err, sizeof(err), "%s", p->err);
        pthread_mutex_unlock(&p->mu);
        if (ev)
            ev(user, 0, err);
        return 0;
    }
    p->idle_ns = 4 * 1000 * 1000;
    if (p->origin_ns == 0 && !p->adec && !p->want_video)
        p->origin_ns = now_ns();
    eof = fill_packets(p);
    if (eof == 1)
        p->fmt_eof = 1;
    pthread_cond_broadcast(&p->cv);
    clock = media_time_locked(p);
    if (need_video(p))
        pump_video(p, clock);
#ifndef FILE_AV_AQ
    if (p->adec)
        pump_audio(p, media_time_locked(p));
#endif
    clock = media_time_locked(p);
    if (p->on_prog && now_ns() - p->last_prog_ns > 1e8) {
        FileAvProgressFn prog = p->on_prog;
        void *user = p->user;
        double dur = p->duration;
        int vw = p->vw, vh = p->vh;
        p->last_prog_ns = now_ns();
        pthread_mutex_unlock(&p->mu);
        prog(user, clock, dur, vw, vh);
        pthread_mutex_lock(&p->mu);
    }
    emit_captions(p);
#ifdef FILE_AV_AQ
    a_empty = !p->adec || ((p->aq.rd >= p->aq.n) && p->ring_n == 0 && !p->a_busy && dac_q_pending(p) == 0);
#else
    a_empty = !p->adec || (p->aq.rd >= p->aq.n);
#endif
    v_empty = !need_video(p) || ((p->vq.rd >= p->vq.n) && p->vout_n == 0 && !p->dec_busy);
    if (eof && a_empty && v_empty && !p->ended && (p->adec || need_video(p))) {
        p->ended = 1;
        p->playing = 0;
        p->hold = p->duration > 0 ? p->duration : clock;
        pthread_mutex_unlock(&p->mu);
        if (p->on_event)
            p->on_event(p->user, 1, NULL);
        return 0;
    }
    idle_ns = p->idle_ns;
    pthread_mutex_unlock(&p->mu);
    if (idle_ns > 0) {
        struct timespec sl = {0, idle_ns};
        nanosleep(&sl, NULL);
    }
    return 1;
}

FileAv *file_av_create(void)
{
    FileAv *p = calloc(1, sizeof(*p));
    VpParams prm = { .tag = "file-av", .held_frames = VOUT_N, .hw_session = 1 };
    if (!p)
        return NULL;
    p->vpipe = vpipe_create(&prm);
    if (!p->vpipe) {
        free(p);
        return NULL;
    }
    pthread_mutex_init(&p->mu, NULL);
    pthread_cond_init(&p->cv, NULL);
    p->speed = 1.0;
    p->fx = audio_fx_create();
    p->want_video = 1;
    p->v_need_key = 0;
    p->audio_index = -1;
    p->last_vpts = -1;
    p->a_st = p->v_st = p->s_st = -1;
    p->subtitle_index = -1;
    p->afr = av_frame_alloc();
    p->vfr = av_frame_alloc();
#ifdef FILE_AV_AQ
    p->out_rate = OUT_RATE;
    p->out_ch = OUT_CH;
#endif
    if (!p->afr || !p->vfr) {
        file_av_destroy(p);
        return NULL;
    }
    if (pthread_create(&p->th, NULL, dec_loop, p) != 0) {
        file_av_destroy(p);
        return NULL;
    }
    p->th_on = 1;
#ifdef FILE_AV_AQ
    if (pthread_create(&p->ath, NULL, a_loop, p) != 0) {
        file_av_destroy(p);
        return NULL;
    }
    p->ath_on = 1;
#endif
    return p;
}

void file_av_destroy(FileAv *p)
{
    int i;
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    p->stop = 1;
    p->playing = 0;
    p->opened = 0;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
    if (p->th_on) {
        pthread_join(p->th, NULL);
        p->th_on = 0;
    }
#ifdef FILE_AV_AQ
    if (p->ath_on) {
        pthread_join(p->ath, NULL);
        p->ath_on = 0;
    }
    stop_aq(p);
#endif
    file_av_close(p);
    vpipe_destroy(p->vpipe);
    vpresent_unbind(p->vp, p);
    vpresent_release(p->vp);
    p->vp = NULL;
    av_frame_free(&p->afr);
    av_frame_free(&p->vfr);
    free(p->pcm);
    free(p->pcm2);
    for (i = 0; i < VOUT_N; i++)
        av_frame_free(&p->vout[i]);
    audio_fx_destroy(p->fx);
    pthread_cond_destroy(&p->cv);
    pthread_mutex_destroy(&p->mu);
    free(p);
}

int file_av_open(FileAv *p, const char *path)
{
    int r;
    if (!p || !path)
        return -1;
    file_av_close(p);
    pthread_mutex_lock(&p->mu);
    p->err[0] = 0;
    p->ended = 0;
    p->hold = 0;
    p->origin_ns = 0;
#ifdef FILE_AV_AQ
    p->seek_base = 0;
    p->samples_played = 0;
    p->dac_started = 0;
    p->dac_tick_ns = 0;
#endif
    p->last_vpts = -1;
    p->logged_drop = 0;
    p->fmt_eof = 0;
    p->dec_drain = 0;
    p->fmt = NULL;
    vpipe_new_stream(p->vpipe);
    r = avformat_open_input(&p->fmt, path, NULL, NULL);
    if (r < 0) {
        char buf[128];
        av_strerror(r, buf, sizeof(buf));
        set_err(p, buf);
        pthread_mutex_unlock(&p->mu);
        return -1;
    }
    if (avformat_find_stream_info(p->fmt, NULL) < 0) {
        set_err(p, "stream info");
        avformat_close_input(&p->fmt);
        pthread_mutex_unlock(&p->mu);
        return -1;
    }
    if (p->fmt->duration > 0)
        p->duration = p->fmt->duration / (double)AV_TIME_BASE;
    else
        p->duration = 0;
    collect_streams(p);
    if (setup_decoders(p) < 0) {
        free_codecs(p);
        avformat_close_input(&p->fmt);
        pthread_mutex_unlock(&p->mu);
        return -1;
    }
    p->opened = 1;
    p->ended = 0;
    pthread_mutex_unlock(&p->mu);
    return 0;
}

void file_av_close(FileAv *p)
{
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    p->opened = 0;
    p->playing = 0;
    pthread_cond_broadcast(&p->cv);
    while (p->dec_busy)
        pthread_cond_wait(&p->cv, &p->mu);
#ifdef FILE_AV_AQ
    while (p->a_busy)
        pthread_cond_wait(&p->cv, &p->mu);
    pthread_mutex_unlock(&p->mu);
    stop_aq(p);
    pthread_mutex_lock(&p->mu);
    p->samples_played = 0;
    p->seek_base = 0;
#endif
    p->fmt_eof = 0;
    p->dec_drain = 0;
    p->v_dead = 0;
    free_codecs(p);
    if (p->fx)
        audio_fx_reset(p->fx);
    if (p->fmt)
        avformat_close_input(&p->fmt);
    free(p->streams);
    p->streams = NULL;
    p->nstreams = 0;
    p->a_st = p->v_st = p->s_st = -1;
    p->vw = p->vh = 0;
    pthread_mutex_unlock(&p->mu);
}

void file_av_play(FileAv *p)
{
#ifdef FILE_AV_AQ
    AudioQueueRef aq = NULL;
    int started = 0;
#endif
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    if (p->opened && !p->playing) {
        p->playing = 1;
        p->ended = 0;
        /* Video-only: clock starts on first present. Audio: AudioQueue samples_played. */
        p->origin_ns = 0;
#ifdef FILE_AV_AQ
        if (!p->dac_started)
            p->seek_base = p->hold;
        else
            p->dac_tick_ns = now_ns();
        aq = p->dac;
        started = p->dac_started;
#endif
        pthread_cond_broadcast(&p->cv);
    }
    pthread_mutex_unlock(&p->mu);
#ifdef FILE_AV_AQ
    if (aq && started)
        AudioQueueStart(aq, NULL);
#endif
}

void file_av_pause(FileAv *p)
{
#ifdef FILE_AV_AQ
    AudioQueueRef aq = NULL;
#endif
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    if (p->playing) {
        p->hold = media_time_locked(p);
        p->playing = 0;
        p->origin_ns = 0;
#ifdef FILE_AV_AQ
        p->dac_tick_ns = 0;
        aq = p->dac;
#endif
        pthread_cond_broadcast(&p->cv);
    }
    pthread_mutex_unlock(&p->mu);
#ifdef FILE_AV_AQ
    if (aq)
        AudioQueuePause(aq);
#endif
}

void file_av_seek(FileAv *p, double seconds)
{
    int64_t ts;
    if (!p)
        return;
#ifdef FILE_AV_AQ
    aq_pause_flush(p);
#endif
    pthread_mutex_lock(&p->mu);
    if (!p->fmt) {
        pthread_mutex_unlock(&p->mu);
        return;
    }
    if (seconds < 0)
        seconds = 0;
    if (p->duration > 0 && seconds > p->duration)
        seconds = p->duration;
    ts = (int64_t)(seconds * AV_TIME_BASE);
    p->fmt_eof = 0;
    p->dec_drain = 0;
    p->dec_epoch++;
    pthread_cond_broadcast(&p->cv);
    while (p->dec_busy)
        pthread_cond_wait(&p->cv, &p->mu);
#ifdef FILE_AV_AQ
    while (p->a_busy)
        pthread_cond_wait(&p->cv, &p->mu);
#endif
    av_seek_frame(p->fmt, -1, ts, AVSEEK_FLAG_BACKWARD);
    if (p->adec)
        avcodec_flush_buffers(p->adec);
    if (p->fx)
        audio_fx_reset(p->fx);
    if (p->v_open)
        vpipe_flush(p->vpipe);
    if (p->sdec)
        avcodec_flush_buffers(p->sdec);
    p->cap_n = 0;
    pq_clear(&p->aq);
    pq_clear(&p->vq);
    av_frame_unref(p->afr);
    av_frame_unref(p->vfr);
    vout_clear(p);
    p->hold = seconds;
    p->ended = 0;
    p->last_vpts = -1;
    p->origin_ns = 0;
#ifdef FILE_AV_AQ
    p->seek_base = seconds;
    p->samples_played = 0;
    p->dac_started = 0;
    p->dac_tick_ns = 0;
    p->ring_r = p->ring_w = p->ring_n = 0;
#endif
#ifdef FILE_AV_PLAYOUT_CLOCK
    memset(p->dac_q_real, 0, sizeof(p->dac_q_real));
#endif
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
}

void file_av_set_speed(FileAv *p, double speed)
{
#ifdef FILE_AV_PLAYOUT_CLOCK
    double played;
    int i;
#endif
    if (!p)
        return;
    if (!(speed > 0.05))
        speed = 0.05;
    pthread_mutex_lock(&p->mu);
    if (p->playing)
        p->hold = media_time_locked(p);
#ifdef FILE_AV_PLAYOUT_CLOCK
    /* hold covers the head buffer's played part; the queue was stretched at the old speed and now counts
       from the new seek_base at the new one: rescale what is left of it. */
    if (p->dac_q_n > 0) {
        played = p->playing && p->dac_tick_ns > 0 ? (now_ns() - p->dac_tick_ns) / 1e9 * p->out_rate : 0;
        p->dac_q_real[0] -= played < p->dac_q_real[0] ? (int)played : p->dac_q_real[0];
    }
    for (i = 0; i < p->dac_q_n; i++)
        p->dac_q_real[i] = (int)(p->dac_q_real[i] * p->speed / speed);
#endif
    p->speed = speed;
    if (p->fx)
        audio_fx_set_speed(p->fx, (float)p->speed);
#ifdef FILE_AV_AQ
    p->seek_base = p->hold;
    p->samples_played = 0;
    p->origin_ns = 0;
    p->dac_tick_ns = p->playing ? now_ns() : 0;
    p->ring_r = p->ring_w = p->ring_n = 0;
#else
    if (p->playing)
        p->origin_ns = now_ns();
#endif
    swr_free(&p->swr_speed);
    p->swr_speed_in = 0;
    pthread_mutex_unlock(&p->mu);
}

void file_av_set_audio_index(FileAv *p, int stream_index)
{
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    p->audio_index = stream_index;
    pthread_mutex_unlock(&p->mu);
}

void file_av_set_subtitle_index(FileAv *p, int stream_index)
{
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    p->subtitle_index = stream_index;
    if (p->opened)
        open_sdec_locked(p);
    pthread_mutex_unlock(&p->mu);
}

int file_av_dump_captions(FileAv *p, int stream_index, FileAvCaptionFn on_cue, void *user)
{
    AVFormatContext *fmt = NULL;
    AVPacket *pkt;
    AVStream *st;
    const char *url;
    unsigned i;
    int n = 0;

    if (!p || !on_cue || stream_index < 0)
        return 0;
    pthread_mutex_lock(&p->mu);
    url = (p->fmt && p->fmt->url) ? p->fmt->url : NULL;
    pthread_mutex_unlock(&p->mu);
    if (!url || avformat_open_input(&fmt, url, NULL, NULL) < 0)
        return 0;
    if (avformat_find_stream_info(fmt, NULL) < 0) {
        avformat_close_input(&fmt);
        return 0;
    }
    if ((unsigned)stream_index >= fmt->nb_streams) {
        avformat_close_input(&fmt);
        return 0;
    }
    st = fmt->streams[stream_index];
    if (st->codecpar->codec_type != AVMEDIA_TYPE_SUBTITLE) {
        avformat_close_input(&fmt);
        return 0;
    }
    for (i = 0; i < fmt->nb_streams; i++)
        fmt->streams[i]->discard = i == (unsigned)stream_index ? AVDISCARD_DEFAULT : AVDISCARD_ALL;
    av_seek_frame(fmt, stream_index, 0, AVSEEK_FLAG_BACKWARD);
    pkt = av_packet_alloc();
    if (!pkt) {
        avformat_close_input(&fmt);
        return 0;
    }
    while (av_read_frame(fmt, pkt) >= 0) {
        char text[1024];
        double pts, dur, start, end;
        if (pkt->stream_index != stream_index) {
            av_packet_unref(pkt);
            continue;
        }
        text[0] = 0;
        if (st->codecpar->codec_id == AV_CODEC_ID_MOV_TEXT)
            parse_mov_text(pkt->data, pkt->size, text, (int)sizeof(text));
        else if (st->codecpar->codec_id == AV_CODEC_ID_SUBRIP ||
                 st->codecpar->codec_id == AV_CODEC_ID_SRT ||
                 st->codecpar->codec_id == AV_CODEC_ID_WEBVTT ||
                 st->codecpar->codec_id == AV_CODEC_ID_TEXT)
            copy_text(pkt->data, pkt->size, text, (int)sizeof(text));
        else if (st->codecpar->codec_id == AV_CODEC_ID_ASS ||
                 st->codecpar->codec_id == AV_CODEC_ID_SSA)
            ass_body((const char *)pkt->data, text, (int)sizeof(text));
        if (text[0]) {
            int64_t t = pkt->pts != AV_NOPTS_VALUE ? pkt->pts : pkt->dts;
            pts = t != AV_NOPTS_VALUE ? t * av_q2d(st->time_base) : 0;
            dur = pkt->duration > 0 ? pkt->duration * av_q2d(st->time_base) : 5.0;
            start = pts;
            end = pts + (dur > 0 ? dur : 5.0);
            on_cue(user, n + 1, start, end, text);
            n++;
        }
        av_packet_unref(pkt);
        if (n >= 8000)
            break;
    }
    av_packet_free(&pkt);
    avformat_close_input(&fmt);
    return n;
}

void file_av_set_video_enabled(FileAv *p, int on)
{
    int want = on ? 1 : 0;
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    if (p->want_video == want) {
        pthread_mutex_unlock(&p->mu);
        return;
    }
    p->want_video = want;
    if (!want)
        rest_video_locked(p);
    else if (p->opened && start_video_locked(p) < 0)
        p->v_dead = 1;
    pthread_cond_broadcast(&p->cv);
    pthread_mutex_unlock(&p->mu);
}

void file_av_bind_presenter(FileAv *p, VPresenter *vp)
{
    VPresenter *old;
    if (!p)
        return;
    /* Before present_head can see it, so its first picture is not dropped. */
    vpresent_bind(vp, p);
    vpresent_retain(vp);
    vpipe_set_presenter(p->vpipe, vp, p);
    pthread_mutex_lock(&p->mu);
    old = p->vp;
    p->vp = vp;
    pthread_mutex_unlock(&p->mu);
    if (old != vp)
        vpresent_unbind(old, p);
    vpresent_release(old);
}

int file_av_frames(FileAv *p)
{
    return p ? vpipe_frames(p->vpipe) : 0;
}

/* audio_fx applies it at the pull; also setting the AudioQueue volume would square the gain. */
void file_av_set_volume(FileAv *p, double vol)
{
    if (p && p->fx)
        audio_fx_set_volume(p->fx, (float)vol);
}

void file_av_set_pitch(FileAv *p, double pitch)
{
    if (p && p->fx)
        audio_fx_set_pitch(p->fx, (float)pitch);
}

void file_av_set_eq(FileAv *p, const float bands_db[10])
{
    if (p && p->fx)
        audio_fx_set_eq(p->fx, bands_db);
}

void file_av_set_preamp(FileAv *p, float db)
{
    if (p && p->fx)
        audio_fx_set_preamp(p->fx, db);
}

void file_av_set_bass(FileAv *p, float db)
{
    if (p && p->fx)
        audio_fx_set_bass(p->fx, db);
}

/* Frames colored at the pull but still queued ahead of the AudioQueue playhead. */
static int vis_delay_frames(FileAv *p)
{
    int delay = 0;
#ifdef FILE_AV_AQ
    pthread_mutex_lock(&p->mu);
    if (p->dac && p->out_rate > 0 && p->dac_buf_bytes > 0) {
        int one = p->dac_buf_bytes / ring_fb(p);
        int extra = 0;
        if (p->dac_tick_ns > 0)
            extra = (int)((now_ns() - p->dac_tick_ns) / 1e9 * p->out_rate);
        if (extra > one)
            extra = one;
        delay = one * AQ_NBUFS - (extra > 0 ? extra : 0);
    }
    pthread_mutex_unlock(&p->mu);
#endif
    return delay;
}

int file_av_pcm_levels(FileAv *p, float *out, int n)
{
    if (!p || !p->fx)
        return 0;
    return audio_fx_levels(p->fx, out, n, vis_delay_frames(p));
}

void file_av_set_virtualizer(FileAv *p, float width)
{
    if (p && p->fx)
        audio_fx_set_virtualizer(p->fx, width);
}

double file_av_duration(FileAv *p)
{
    double d;
    if (!p)
        return 0;
    pthread_mutex_lock(&p->mu);
    d = p->duration;
    pthread_mutex_unlock(&p->mu);
    return d;
}

double file_av_position(FileAv *p)
{
    double d;
    if (!p)
        return 0;
    pthread_mutex_lock(&p->mu);
    d = media_time_locked(p);
    pthread_mutex_unlock(&p->mu);
    return d;
}

int file_av_ended(FileAv *p)
{
    int e;
    if (!p)
        return 0;
    pthread_mutex_lock(&p->mu);
    e = p->ended;
    pthread_mutex_unlock(&p->mu);
    return e;
}

int file_av_video_size(FileAv *p, int *w, int *h)
{
    if (!p)
        return 0;
    pthread_mutex_lock(&p->mu);
    if (w)
        *w = p->vw;
    if (h)
        *h = p->vh;
    pthread_mutex_unlock(&p->mu);
    return p && p->vw > 0 && p->vh > 0;
}

const char *file_av_last_error(FileAv *p)
{
    return p ? p->err : "nil";
}

int file_av_stream_count(FileAv *p)
{
    int n;
    if (!p)
        return 0;
    pthread_mutex_lock(&p->mu);
    n = p->nstreams;
    pthread_mutex_unlock(&p->mu);
    return n;
}

int file_av_stream_at(FileAv *p, int i, int *kind, int *index, int *w, int *h,
                      char *lang, int lang_n, char *codec, int codec_n)
{
    StreamInfo s;
    if (!p)
        return -1;
    pthread_mutex_lock(&p->mu);
    if (i < 0 || i >= p->nstreams) {
        pthread_mutex_unlock(&p->mu);
        return -1;
    }
    s = p->streams[i];
    pthread_mutex_unlock(&p->mu);
    if (kind)
        *kind = s.kind;
    if (index)
        *index = s.index;
    if (w)
        *w = s.w;
    if (h)
        *h = s.h;
    if (lang && lang_n > 0)
        snprintf(lang, (size_t)lang_n, "%s", s.lang);
    if (codec && codec_n > 0)
        snprintf(codec, (size_t)codec_n, "%s", s.codec);
    return 0;
}

void file_av_set_sinks(FileAv *p, FileAvPcmFn on_pcm, FileAvProgressFn on_prog,
                       FileAvEventFn on_event, FileAvCaptionFn on_caption, void *user)
{
    if (!p)
        return;
    pthread_mutex_lock(&p->mu);
    p->on_pcm = on_pcm;
    p->on_prog = on_prog;
    p->on_event = on_event;
    p->on_caption = on_caption;
    p->user = user;
    pthread_mutex_unlock(&p->mu);
}

void *file_av_user(FileAv *p)
{
    void *u;
    if (!p)
        return NULL;
    pthread_mutex_lock(&p->mu);
    u = p->user;
    pthread_mutex_unlock(&p->mu);
    return u;
}
